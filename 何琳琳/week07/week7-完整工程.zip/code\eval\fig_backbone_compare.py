"""
骨干对比图：同样的配置下，"换架构"与"换领域语料"分别值多少。

为什么单独出图：eval/make_figures.py 里的 METHODS/ABLATIONS 是老师原工程的清单，
本机新增的 4 个全量实验没有在里面；把它们塞进主图会让 12 根柱子挤在一起。
这张图只讲本机实验这条线（BiLSTM-CRF 作参照 + 3 个 4 层 BERT 骨干）。

数据来源：outputs/metrics/disc/*.json（每个数字都能反查到 run_name），不硬编码。
用法：python eval/fig_backbone_compare.py
"""
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "eval"))
from make_figures import setup_style, save   # 复用统一的中文字体与保存口径

METRIC_DIR = ROOT / "outputs" / "metrics" / "disc"

# (run_name, 图例标签, 颜色)
METHODS = [
    ("bilstm_crf_full_data",          "BiLSTM-CRF\n1.31M / 300s", "#54A24B"),
    ("bert4L_linear_256_full_data",   "BERT-4L\n45.7M",          "#4C78A8"),
    ("roberta4L_linear_256_full_data", "RoBERTa-4L\n45.7M",      "#B279A2"),
    ("finbert4L_linear_256_full_data", "FinBERT-4L\n45.7M",      "#F58518"),
]
# 天花板参照（老师在 GPU 上跑的 12 层，只放心到成本图上）
CEIL_KEY = "bert_linear_256"
CEIL_LABEL = "BERT-12L 天花板（老师，GPU）"


def load(key: str) -> dict | None:
    p = METRIC_DIR / f"{key}.json"
    if not p.exists():
        return None
    return json.loads(p.read_text("utf-8"))


def main() -> None:
    setup_style()

    rows = []
    for key, label, color in METHODS:
        r = load(key)
        if r is None:
            print(f"  [skip] {key} 缺少指标文件")
            continue
        meta = r.get("meta") or {}
        rows.append({
            "label": label,
            "color": color,
            "trig": r["trigger"]["f1"],
            "arg": r["argument"]["f1"],
            "ev": r["event_exact"]["f1"],
            "train_s": float(meta.get("train_s") or 0.0),
            "ms": float(meta.get("ms_per_sentence") or 0.0),
        })
    if not rows:
        print("没有可用的指标文件，退出。")
        return

    fig, axes = plt.subplots(1, 2, figsize=(14.2, 5.8))

    # ── 左：三项指标分组柱状 ──
    ax = axes[0]
    x = np.arange(len(rows))
    w = 0.26
    for i, (name, field, col) in enumerate(
            [("触发词 F1", "trig", "#4C78A8"),
             ("论元 F1", "arg", "#F58518"),
             ("事件级 F1", "ev", "#54A24B")]):
        vals = [r[field] for r in rows]
        bars = ax.bar(x + (i - 1) * w, vals, w, label=name, color=col,
                      edgecolor="white", linewidth=0.6)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.012, f"{v:.3f}",
                    ha="center", va="bottom", fontsize=9.5)
    ax.set_xticks(x)
    ax.set_xticklabels([r["label"] for r in rows], fontsize=9.5)
    ax.set_ylim(0, 0.95)
    ax.set_ylabel("F1 分数")
    ax.set_title("同一份数据（全量 / 3 epoch）：只换骨干", pad=12)
    ax.legend(frameon=False, loc="upper right")

    # ── 右：成本—效果散点（横轴对数更直观：1520s 与 5022s 差 3 倍） ──
    ax = axes[1]
    for r in rows:
        ax.scatter(r["train_s"], r["arg"], s=150, color=r["color"], zorder=3,
                   edgecolor="white", linewidth=1.3)
        ax.annotate(r["label"].split("\n")[0], (r["train_s"], r["arg"]),
                    textcoords="offset points", xytext=(9, 6), fontsize=9.5)
    c = load(CEIL_KEY)
    if c is not None:
        # 12 层那组是老师的 GPU 耗时（636s），与 CPU 点不同硬件，不能落在同一横轴上；
        # 只画一条水平参考线表示「高度天花板」，不标 x 位置。
        ceil_f1 = c["argument"]["f1"]
        ax.axhline(ceil_f1, color="#9E9E9E", linestyle="--", linewidth=1.2, alpha=0.9)
        ax.text(210, ceil_f1 + 0.012, CEIL_LABEL + f" = {ceil_f1:.3f}",
                fontsize=9, color="#616161")
    ax.set_xscale("log")
    ax.set_xlim(200, 6000)
    ax.set_xticks([300, 500, 1000, 2000, 5000])
    ax.set_xticklabels(["300", "500", "1k", "2k", "5k"])
    ax.set_xlabel("训练耗时（秒，本机 CPU；对数轴）")
    ax.set_ylabel("论元 F1")
    ax.set_ylim(0, 0.65)
    ax.set_title("成本—效果：谁的论元 F1 更「便宜」", pad=12)

    fig.tight_layout()
    save(fig, "fig_backbone_compare.png")


if __name__ == "__main__":
    main()
