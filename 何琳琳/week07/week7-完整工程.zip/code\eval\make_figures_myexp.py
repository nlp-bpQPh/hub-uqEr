"""
按老师 NOTES_discriminative.md §8.3 的图表清单，把 6 张「PPT 用图」重做成本机实验的版本。

与 make_figures.py 的区别：那边的 MAIN_METHODS / ABLATIONS 是老师原工程的清单（12 层为主），
本脚本只换数据源，图形样式、坐标、标注口径完全复用老师那 6 个函数 —— 保证"形式一样"。

用法：python eval/make_figures_myexp.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "eval"))
from make_figures import (          # noqa: E402
    setup_style, fig_method_comparison, fig_illegal_bio,
    fig_per_role, fig_training_curves, fig_type_confusion, fig_latency_cost,
)

# 主图/成本图用的方法清单：本机 9 组实验 + 共同基线（规则）
MY_METHODS = [
    ("rule",                          "L0 规则"),
    ("bilstm_crf_full_data",          "BiLSTM-CRF"),
    ("bert4L_linear_256_full_data",   "BERT-4L 256"),
    ("bert4L_linear_128_full_data",   "BERT-4L 128"),
    ("roberta4L_linear_256_full_data", "RoBERTa-4L"),
    ("finbert4L_linear_256_full_data", "FinBERT-4L"),
    ("bert4L_crf_256_full_data",      "BERT-4L 256 +CRF"),
    ("bert4L_crf_256_full_data_hard", "BERT-4L 256 +CRF+硬约束"),
]

# 训练曲线：只放 BERT 系列 5 条。
# 不能混 BiLSTM —— 它的 train_loss 是 CRF 的负对数似然（230 → 49），
# 和 softmax-CE（1.7 → 0.45）量级差两个数量级，放同一面板会把其余曲线压成一条直线。
MY_RUNS = [
    ("bert_linear_256",                "BERT 12L（参照）"),
    ("bert4L_linear_256_full_data",    "BERT 4L 256"),
    ("bert4L_linear_128_full_data",    "BERT 4L 128"),
    ("roberta4L_linear_256_full_data", "RoBERTa 4L"),
    ("finbert4L_linear_256_full_data", "FinBERT 4L"),
]


def main() -> None:
    setup_style()

    # 1) 方法对比（三级 F1 并排）
    fig_method_comparison(MY_METHODS)

    # 2) 非法 BIO：金标地板 → 4 个 Linear → BERT-4L+CRF（软约束几乎没用）→ BiLSTM 的 CRF → 本机硬约束
    fig_illegal_bio([
        ("BERT-4L 256", "bert4L_linear_256_full_data", "bert4L_crf_256_full_data"),
        ("BERT-4L 128", "bert4L_linear_128_full_data",   ""),
        ("RoBERTa-4L",  "roberta4L_linear_256_full_data", ""),
        ("FinBERT-4L",  "finbert4L_linear_256_full_data", ""),
        ("BiLSTM",      "", "bilstm_crf_full_data"),
    ], hard_key="bert4L_crf_256_full_data_hard")

    # 3) 逐角色论元 F1：取论元 F1 最高的模型，看它到底差在哪类角色
    fig_per_role("bilstm_crf_full_data", "BiLSTM-CRF")

    # 4) 训练曲线（loss + 内层验证 span F1）
    fig_training_curves(MY_RUNS)

    # 5) 类型混淆矩阵：取类型 macro 最高的模型
    fig_type_confusion("finbert4L_linear_256_full_data", "FinBERT-4L")

    # 6) 精度 / 延迟 / 参数量三角权衡
    fig_latency_cost(MY_METHODS)

    print("完成：6 张图均按老师 §8.3 清单重做。")


if __name__ == "__main__":
    main()
