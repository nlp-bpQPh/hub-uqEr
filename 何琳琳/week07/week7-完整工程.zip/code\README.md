# week7 · 信息抽取（事件抽取）多模型对比

纯 CPU（无 GPU）复现老师的 week7 工程，并在此基础上做**多骨干 / 多解码 / 多长度 / 多数据量**的单变量对比。

**11 组可比结果**，覆盖 5 个变量维度；在"CPU + 5173 句标注"约束下的最优解是 **BERT-4L + CRF + 解码期硬约束**：论元 F1 **0.5286**、非法 BIO 从 **84.6% 压到 6.1%**、后处理零训练成本。

## 先看哪份

**入口是 [`交付说明.md`](交付说明.md)** —— 按"5 分钟 / 15 分钟 / 想核过程 / 想复现"四档写清了该打开哪份、看哪几节。

| 文件 | 作用 |
|---|---|
| `交付说明.md` | 入口：看什么、怎么看、四条口径声明 |
| `week7-信息抽取-方法对比报告.md` | 结论与论证（8 节 + 附录 A 实验清单 / B 数字溯源 / C 老师基线参照） |
| `EXPERIMENTS.md` | 过程与决策（E01~E10b 每条：命令 / 配置 / 结果 / 判断 / 决策） |
| `NOTES_myexp.md` | 工程与命令（9 章：数据格式、全部命令、关键设计、踩坑 15 条） |

## 目录

```
bert/            BERT 单句联合抽取（linear / crf / 层数 / 长度 / 骨干）
bilstm_crf/      BiLSTM-CRF 基线（无预训练，3.92ms/句）
bert_pipeline/   两段式流水线（检测器 + 16 个类型专家）—— 本轮未跑，见报告 §8
rule/            规则基线（0 训练）
common/          数据、模型、CRF、评测的公共实现
eval/            汇总表与出图（含新增 make_figures_myexp.py / fig_backbone_compare.py）
service/         篇章级端到端演示（带金标对照）
outputs/         metrics/*.json（每方法一份）、figures/（7 张图）、logs/、disc/（逐句预测）
data/processed/  8 个 jsonl 与 event_schema.json（5700+ 句 / 149 标签 / 92 槽位）
```

## 复现

```powershell
cd code
python eval\compare_methods.py      # → outputs\metrics\disc\summary.md
python eval\make_figures_myexp.py   # → outputs\figures\ 6 张图
```

训练命令逐条列在 `NOTES_myexp.md §2`（CPU 上串行跑完 11 组约 7.5 小时）。

## 没有提交的东西（有意为之）

| 未提交 | 大小 | 原因 |
|---|---|---|
| `outputs/checkpoints/` | 8×174MB | 超过 GitHub 单文件 100MB 上限；权重可由 `NOTES_myexp.md §2` 的命令重训得到 |
| `pretrain_models/` | 3.6GB | 公开权重（bert-base-chinese / roberta-base / finbert-zh），按 `NOTES §2` 的路径自行下载 |

所有**指标、日志、预测、图**都已提交，因此每个报告数字都能在 `outputs/metrics/disc/<run_name>.json` 里反查，不需要权重也能核对结论。
