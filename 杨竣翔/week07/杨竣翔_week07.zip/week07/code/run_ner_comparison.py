"""第七周 NER 对照实验。复用课件编码器、CRF 和人民日报数据的实体级评估。"""

import argparse
from collections import Counter
from contextlib import nullcontext
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import sys
import time

import torch
from torch.nn import functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence, pad_sequence
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, get_linear_schedule_with_warmup

ROOT = Path(__file__).resolve().parents[1]
COURSE = ROOT / "code" / "course"
NER = ROOT / "code" / "sequence_labeling"
ROBERTA = Path("D:/model/RoBERTa-Chinese-base")
sys.path[:0] = [str(COURSE / "common"), str(COURSE), str(NER / "src")]

from bilstm_crf.train import BiLSTMEncoder
from crf import CRFClassifier
from dataset import (PEOPLES_DAILY_TAGS as TAGS, PEOPLES_DAILY_TAG_TO_ID as TAG_TO_ID,
                     load_peoples_daily, peoples_daily_gold, peoples_daily_metrics,
                     peoples_daily_spans, select_peoples_daily, split_peoples_daily)
from event_data import build_bio_constraint_mask, build_start_constraint_mask, illegal_bio_stats
from model import resolve_peoples_daily_bert
from models import BertEncoder

METHODS = {
    "roberta_linear": ("RoBERTa + Linear", "roberta", False),
    "roberta_crf": ("RoBERTa + CRF", "roberta", True),
    "bert_linear": ("BERT + Linear", "bert", False),
    "bert_crf": ("BERT + CRF", "bert", True),
    "bilstm_crf": ("BiLSTM + CRF", "bilstm", True),
}
ENTITY_TYPES = ("PER", "ORG", "LOC")
MAX_CHARS, STRIDE = 192, 144


class PackedBiLSTM(BiLSTMEncoder):
    """按真实序列长度运行课件 BiLSTM，防止反向 LSTM 读到右侧补齐。"""

    def forward(self, input_ids, attention_mask, token_type_ids=None):
        embeddings = self.dropout(self.emb(input_ids))
        packed = pack_padded_sequence(embeddings, attention_mask.sum(1).cpu(),
                                      batch_first=True, enforce_sorted=False)
        states, _ = self.lstm(packed)
        return pad_packed_sequence(states, batch_first=True, total_length=input_ids.size(1))[0]


def write_json(path, value):
    """先写完整文件，再替换目标，便于按方法恢复中断的实验。"""
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def inference_windows(tokens):
    """用原文字符数决定窗口位置，相邻窗口重叠以保留实体附近的上下文。"""
    for start in range(0, len(tokens), STRIDE):
        end = start + MAX_CHARS
        yield start, tokens[start:end], None
        if end >= len(tokens):
            break


def make_examples(selected, tokenizer, vocabulary, training=False):
    """预先编码并记录每个原字符对应的首子词位置，验证和测试只读取原文。"""
    examples = []
    for index, row in selected:
        windows = (split_peoples_daily(row, MAX_CHARS) if training
                   else inference_windows(row["tokens"]))
        for offset, chars, tags in windows:
            if tokenizer is None:
                ids = [vocabulary.get(char, 1) for char in chars]
                positions = list(range(len(chars)))
            else:
                encoded = tokenizer(chars, is_split_into_words=True, verbose=False)
                ids = encoded["input_ids"]
                first_positions = {}
                for i, word_id in enumerate(encoded.word_ids()):
                    if word_id is not None:
                        first_positions.setdefault(word_id, i)
                if len(first_positions) != len(chars):
                    # 被分词器清洗掉的字符用 UNK 代替，避免实体坐标缩短。
                    chars = [char if i in first_positions else tokenizer.unk_token
                             for i, char in enumerate(chars)]
                    encoded = tokenizer(chars, is_split_into_words=True, verbose=False)
                    ids = encoded["input_ids"]
                    first_positions = {}
                    for i, word_id in enumerate(encoded.word_ids()):
                        if word_id is not None:
                            first_positions.setdefault(word_id, i)
                positions = [first_positions[i] for i in range(len(chars))]
                if len(ids) > 512:
                    raise ValueError(f"第 {index} 句的窗口超过编码器长度上限")
            labels = [TAG_TO_ID[tag] for tag in tags] if tags is not None else [0] * len(chars)
            examples.append((index, offset, ids, positions, labels))
    return examples


def collate(batch):
    """分别补齐编码器输入和字符级标签，CRF 只接收有效字符构成的连续前缀。"""
    indices, offsets, ids, positions, labels = zip(*batch)
    inputs = pad_sequence([torch.tensor(row) for row in ids], batch_first=True)
    first = pad_sequence([torch.tensor(row) for row in positions], batch_first=True)
    gold = pad_sequence([torch.tensor(row) for row in labels], batch_first=True)
    attention = torch.arange(inputs.size(1)) < torch.tensor([len(row) for row in ids])[:, None]
    valid = torch.arange(gold.size(1)) < torch.tensor([len(row) for row in labels])[:, None]
    return indices, offsets, tuple(map(len, labels)), inputs, attention, first, gold, valid


def character_logits(model, ids, attention, positions, device, mixed_precision):
    """取首子词的发射分数，在线性头与 CRF 中使用同一份字符级输出。"""
    precision = torch.autocast("cuda", dtype=torch.bfloat16) if mixed_precision else nullcontext()
    with precision:
        scores = model.emissions(ids.to(device), attention.to(device))
    positions = positions.to(device).unsqueeze(-1).expand(-1, -1, len(TAGS))
    return scores.gather(1, positions).float()


def evaluate(model, loader, selected, device, mixed_precision):
    """平均重叠区的发射分数，再恢复整句 BIO 序列并按实体边界计分。"""
    model.eval()
    scores = {i: torch.zeros(len(row["tokens"]), len(TAGS)) for i, row in selected}
    counts = {i: torch.zeros(len(values), 1) for i, values in scores.items()}
    with torch.inference_mode():
        for ids, offsets, lengths, tokens, attention, first, _, _ in loader:
            logits = character_logits(model, tokens, attention, first, device, mixed_precision).cpu()
            for index, offset, length, score in zip(ids, offsets, lengths, logits):
                positions = slice(offset, offset + length)
                scores[index][positions] += score[:length]
                counts[index][positions] += 1
        if any((count == 0).any() for count in counts.values()):
            raise RuntimeError("评估窗口未覆盖所有原文字符")
        sentences = [scores[i] / counts[i] for i, _ in selected]
        paths = []
        if model.crf is None:
            paths = [sentence.argmax(-1).tolist() for sentence in sentences]
        else:
            # 将完整句子的 CRF 回溯放在 CPU，避免逐标签访问引发 GPU 同步。
            crf = deepcopy(model.crf).cpu()
            for start in range(0, len(sentences), 32):
                group = sentences[start:start + 32]
                padded = pad_sequence(group, batch_first=True)
                valid = torch.arange(padded.size(1)) < torch.tensor([len(s) for s in group])[:, None]
                paths.extend(crf.decode(padded, valid))
    tags = [[TAGS[i] for i in path] for path in paths]
    gold = [peoples_daily_gold(row) for _, row in selected]
    predictions = [peoples_daily_spans(sequence) for sequence in tags]
    return gold, predictions, tags


def summarize(gold, predicted, tags):
    return {
        "micro": peoples_daily_metrics(gold, predicted),
        "by_type": {kind: peoples_daily_metrics(
            [{e for e in row if e[2] == kind} for row in gold],
            [{e for e in row if e[2] == kind} for row in predicted]) for kind in ENTITY_TYPES},
        "illegal_bio": illegal_bio_stats(tags),
        "sentences": len(gold),
    }


def train(method, args, splits, protocol, output, device, mixed_precision):
    label, family, use_crf = METHODS[method]
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    train_rows, validation, test = splits
    pretrained = None
    if family == "bilstm":
        # 字表只由训练样本生成。0 是补齐值，1 是未登录字符。
        counter = Counter(char for _, row in train_rows for char in row["tokens"])
        vocabulary = {char: i for i, char in enumerate(sorted(counter), 2)}
        tokenizer = None
        encoder = PackedBiLSTM(len(vocabulary) + 2)
        lr, head_lr = 1e-3, 1e-3
    else:
        pretrained = str(args.roberta if family == "roberta" else resolve_peoples_daily_bert())
        vocabulary = None
        tokenizer = AutoTokenizer.from_pretrained(pretrained, local_files_only=True)
        encoder = BertEncoder(pretrained)
        lr, head_lr = 2e-5, 1e-4
    if tokenizer is not None and tokenizer.pad_token_id != 0:
        raise ValueError("本实验的动态补齐要求模型的 PAD id 为 0")
    scheme = {"labels": TAGS}
    model = CRFClassifier(encoder, encoder.hidden_size, len(TAGS), dropout=0.1, use_crf=use_crf,
                          constraint=build_bio_constraint_mask(scheme),
                          start_constraint=build_start_constraint_mask(scheme)).to(device)
    print(f"[{label}] 编码训练和验证样本", flush=True)
    fit = make_examples(train_rows, tokenizer, vocabulary, training=True)
    val = make_examples(validation, tokenizer, vocabulary)
    loader = DataLoader(fit, batch_size=args.batch_size, shuffle=True, collate_fn=collate,
                        generator=torch.Generator().manual_seed(args.seed))
    val_loader = DataLoader(val, batch_size=args.batch_size, collate_fn=collate)
    optimizer = torch.optim.AdamW([
        {"params": model.encoder.parameters(), "lr": lr},
        {"params": [p for n, p in model.named_parameters() if not n.startswith("encoder.")],
         "lr": head_lr},
    ], weight_decay=0.01, fused=device.type == "cuda")
    steps = len(loader) * args.epochs
    scheduler = get_linear_schedule_with_warmup(optimizer, int(steps * 0.1), steps)
    checkpoint = output / "checkpoints" / f"{method}.pt"
    best_f1, history = -1.0, []
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    train_start = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train()
        loss_sum = 0.0
        for step, batch in enumerate(loader, 1):
            _, _, _, tokens, attention, first, gold, valid = batch
            optimizer.zero_grad(set_to_none=True)
            scores = character_logits(model, tokens, attention, first, device, mixed_precision)
            gold, valid = gold.to(device), valid.to(device)
            loss = (model.crf.neg_log_likelihood(scores, gold, valid) if use_crf else
                    F.cross_entropy(scores.flatten(0, 1), gold.masked_fill(~valid, -100).flatten()))
            if not torch.isfinite(loss):
                raise RuntimeError(f"{label} 第 {epoch} 轮第 {step} 步出现非有限损失")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            loss_sum += loss.item()
            if step % 25 == 0:
                print(f"[{label}] 轮次 {epoch} 步数 {step}/{len(loader)} loss={loss_sum / step:.4f}",
                      flush=True)
        golds, preds, _ = evaluate(model, val_loader, validation, device, mixed_precision)
        scores = peoples_daily_metrics(golds, preds)
        history.append({"epoch": epoch, "train_loss": loss_sum / len(loader), "validation": scores})
        print(f"[{label}] 第 {epoch} 轮验证 F1={scores['f1']:.4f}", flush=True)
        if scores["f1"] > best_f1:
            best_f1, best_epoch = scores["f1"], epoch
            temporary = checkpoint.with_suffix(".pt.tmp")
            torch.save({"state_dict": model.state_dict(), "epoch": epoch, "tags": TAGS,
                        "method": method, "pretrained": pretrained, "vocabulary": vocabulary,
                        "protocol": protocol}, temporary)
            temporary.replace(checkpoint)
    training_seconds = time.perf_counter() - train_start
    peak_memory = torch.cuda.max_memory_allocated() / 2**20 if device.type == "cuda" else None
    model.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=True)["state_dict"])
    test_examples = make_examples(test, tokenizer, vocabulary)
    test_loader = DataLoader(test_examples, batch_size=args.batch_size, collate_fn=collate)
    test_start = time.perf_counter()
    gold, pred, tags = evaluate(model, test_loader, test, device, mixed_precision)
    test_seconds = time.perf_counter() - test_start
    subset = set(protocol["legacy_test_ids"])
    subset_gold, subset_pred, subset_tags = zip(*[(g, p, t) for (i, _), g, p, t in zip(test, gold, pred, tags)
                                                  if i in subset])
    result = {
        "method": method, "label": label, "pretrained": pretrained, "decoder": "CRF" if use_crf else "Linear",
        "learning_rates": [lr, head_lr], "best_epoch": best_epoch, "history": history,
        "fit_windows": len(fit), "validation_windows": len(val), "test_windows": len(test_examples),
        "training_seconds": training_seconds, "test_seconds": test_seconds,
        "peak_training_memory_mib": peak_memory,
        "parameters": sum(p.numel() for p in model.parameters()),
        "full_test": summarize(gold, pred, tags),
        "legacy_test": summarize(subset_gold, subset_pred, subset_tags),
        "protocol_sha256": protocol["sha256"],
    }
    with (output / "predictions" / f"{method}.jsonl").open("w", encoding="utf-8") as stream:
        for (index, _), gold_row, pred_row in zip(test, gold, pred):
            stream.write(json.dumps({"id": index, "gold": sorted(gold_row), "predicted": sorted(pred_row)},
                                    ensure_ascii=False) + "\n")
    write_json(output / "metrics" / f"{method}.json", result)
    print(f"[{label}] 完整测试 F1={result['full_test']['micro']['f1']:.4f}，"
          f"训练及验证 {training_seconds:.1f} 秒", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--roberta", type=Path, default=ROBERTA)
    parser.add_argument("--result-dir", type=Path, default=ROOT / "result")
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=list(METHODS))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--train-limit", type=int, default=2000)
    parser.add_argument("--validation-limit", type=int, default=300)
    parser.add_argument("--force", action="store_true", help="重新训练指定方法")
    args = parser.parse_args()
    if min(args.epochs, args.batch_size, args.train_limit, args.validation_limit) < 1:
        parser.error("训练轮数、批大小和样本数必须为正数")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.set_num_threads(2)
    if device.type == "cuda":
        torch.set_float32_matmul_precision("high")
    mixed_precision = device.type == "cuda" and torch.cuda.is_bf16_supported()
    data = {split: load_peoples_daily(split) for split in ("train", "validation", "test")}
    splits = [select_peoples_daily(data[split], limit, args.seed) for split, limit in zip(
        data, (args.train_limit, args.validation_limit, -1))]
    legacy_test = select_peoples_daily(data["test"], 100, 42)
    protocol = {
        "dataset": "人民日报 NER", "types": ENTITY_TYPES, "seed": args.seed, "epochs": args.epochs,
        "batch_size": args.batch_size, "max_window_chars": MAX_CHARS, "inference_stride": STRIDE,
        "device": str(device), "gpu": torch.cuda.get_device_name() if device.type == "cuda" else None,
        "transformer_precision": "BF16 AMP" if mixed_precision else "FP32",
        "roberta_path": str(args.roberta.resolve()),
        "ids": {name: [i for i, _ in selected] for name, selected in zip(data, splits)},
        "legacy_test_ids": [i for i, _ in legacy_test],
        "data_sha256": {split: hashlib.sha256((NER / "data" / "peoples_daily" /
                                               f"{split}.json").read_bytes()).hexdigest() for split in data},
    }
    protocol["sha256"] = hashlib.sha256(json.dumps(protocol, sort_keys=True).encode()).hexdigest()
    output = args.result_dir.resolve()
    for directory in ("metrics", "predictions", "checkpoints"):
        (output / directory).mkdir(parents=True, exist_ok=True)
    protocol_file = output / "experiment_config.json"
    if (protocol_file.exists() and json.loads(protocol_file.read_text(encoding="utf-8"))["sha256"] !=
            protocol["sha256"]):
        parser.error("实验设置已变化，请用 --result-dir 指定新目录")
    write_json(protocol_file, protocol)
    print(f"设备 {device}，训练/验证/测试 {tuple(map(len, splits))}", flush=True)
    for method in args.methods:
        metric_path = output / "metrics" / f"{method}.json"
        artifacts = [metric_path, output / "predictions" / f"{method}.jsonl",
                     output / "checkpoints" / f"{method}.pt"]
        if not args.force and all(path.is_file() for path in artifacts):
            previous = json.loads(metric_path.read_text(encoding="utf-8"))
            if previous["protocol_sha256"] == protocol["sha256"]:
                print(f"[{METHODS[method][0]}] 复用本目录已完成结果", flush=True)
                continue
        train(method, args, splits, protocol, output, device, mixed_precision)
        if device.type == "cuda":
            torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
