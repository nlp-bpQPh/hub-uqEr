"""
NER 数据集类：span 标注→BIO 转换 + BERT 子词对齐

教学重点：
  1. cluener2020 的 span 格式转为 BIO 格式
     - span: {"name": {"叶老桂": [[9, 11]]}}
     - BIO:  ['O','O',...,'B-name','I-name','I-name',...]
  2. BERT 子词对齐（word_ids 策略）
     - 中文字符通常一字一token，但 [UNK] 和特殊字符可能例外
     - 非首子词标记为 -100，在 loss 计算中被忽略
  3. DataLoader 工厂函数统一封装

使用方式：
  from dataset import build_label_schema, build_dataloaders
"""

import json
import random
from pathlib import Path
from typing import Optional

import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer

ROOT = Path(__file__).parent.parent
DATA_DIR = ROOT / "data" / "cluener"

ENTITY_TYPES = [
    "address", "book", "company", "game",
    "government", "movie", "name", "organization",
    "position", "scene",
]


def build_label_schema() -> tuple[list[str], dict[str, int], dict[int, str]]:
    """构建 BIO 标签体系，返回 (labels, label2id, id2label)。"""
    labels = ["O"]
    for etype in ENTITY_TYPES:
        labels.append(f"B-{etype}")
        labels.append(f"I-{etype}")

    label2id = {lbl: i for i, lbl in enumerate(labels)}
    id2label = {i: lbl for lbl, i in label2id.items()}
    return labels, label2id, id2label


def span_to_bio(text: str, label_dict: dict, label2id: dict) -> list[int]:
    """将 cluener2020 的 span 格式标注转为逐字符 BIO 标签 id 列表。

    教学要点：先全部初始化为 O，再按 span 位置填入 B/I。
    若存在嵌套实体（本数据集极少），外层实体覆盖内层。
    """
    n = len(text)
    bio = ["O"] * n

    if not label_dict:
        return [label2id[t] for t in bio]

    for etype, spans in label_dict.items():
        b_tag = f"B-{etype}"
        i_tag = f"I-{etype}"
        for surface, positions in spans.items():
            for start, end in positions:
                if start >= n or end >= n:
                    continue
                bio[start] = b_tag
                for idx in range(start + 1, end + 1):
                    bio[idx] = i_tag

    return [label2id.get(t, 0) for t in bio]


class CluenerDataset(Dataset):
    """cluener2020 的 PyTorch Dataset。

    教学流程：
      text → span_to_bio → 字符级 BIO ids
           → BertTokenizer (is_split_into_words=True)
           → 用 word_ids() 对齐子词标签（非首子词设为 -100）
           → 返回 input_ids / attention_mask / token_type_ids / labels
    """

    def __init__(
        self,
        records: list,
        tokenizer: BertTokenizer,
        label2id: dict,
        max_length: int = 128,
    ):
        self.records = records
        self.tokenizer = tokenizer
        self.label2id = label2id
        self.max_length = max_length

    def __len__(self):
        return len(self.records)

    def __getitem__(self, idx: int) -> dict:
        row = self.records[idx]
        text: str = row["text"]
        label_dict: dict = row.get("label") or {}

        # 1. span → 字符级 BIO id 列表
        char_labels = span_to_bio(text, label_dict, self.label2id)

        # 2. 将文本拆为字符列表，传入 tokenizer
        #    is_split_into_words=True：把 word_ids() 与字符索引对齐
        chars = list(text)
        encoding = self.tokenizer(
            chars,
            is_split_into_words=True,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )

        # 3. 子词对齐：取每个 token 对应的字符索引
        #    - word_ids() 返回 [None, 0, 0, 1, 2, 2, ..., None]
        #      None 对应 [CLS]/[SEP]/[PAD]
        #    - 一个中文字符通常只有 1 个子词，但 ##xx 子词是非首子词
        #    - 非首子词、特殊token 标记为 -100，cross_entropy 的 ignore_index
        word_ids = encoding.word_ids(batch_index=0)
        aligned_labels = []
        prev_word_id = None
        for wid in word_ids:
            if wid is None:
                aligned_labels.append(-100)
            elif wid != prev_word_id:
                # 首次出现这个字符索引：使用 BIO 标签
                if wid < len(char_labels):
                    aligned_labels.append(char_labels[wid])
                else:
                    aligned_labels.append(-100)
                prev_word_id = wid
            else:
                # 同一字符的后续子词（中文通常不会出现，但保留正确处理）
                aligned_labels.append(-100)

        labels_tensor = torch.tensor(aligned_labels, dtype=torch.long)

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "token_type_ids": encoding["token_type_ids"].squeeze(0),
            "labels": labels_tensor,
        }


def load_records(split: str, data_dir: Optional[Path] = None) -> list:
    d = data_dir or DATA_DIR
    with open(d / f"{split}.json", "r", encoding="utf-8") as f:
        return json.load(f)


def build_dataloaders(
    tokenizer: BertTokenizer,
    label2id: dict,
    batch_size: int = 32,
    max_length: int = 128,
    data_dir: Optional[Path] = None,
) -> tuple[DataLoader, DataLoader, DataLoader]:
    """构建训练/验证/测试 DataLoader，返回 (train_loader, val_loader, test_loader)。"""
    train_records = load_records("train", data_dir)
    val_records = load_records("validation", data_dir)
    test_records = load_records("test", data_dir)

    train_ds = CluenerDataset(train_records, tokenizer, label2id, max_length)
    val_ds = CluenerDataset(val_records, tokenizer, label2id, max_length)
    test_ds = CluenerDataset(test_records, tokenizer, label2id, max_length)

    print(f"数据集规模：训练={len(train_ds)}，验证={len(val_ds)}，测试={len(test_ds)}")

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=0)

    return train_loader, val_loader, test_loader


# 人民日报数据沿用本文件的数据职责：统一读取、切句、对齐与实体级评分。
PEOPLES_DAILY_DIR = ROOT / "data" / "peoples_daily"
PEOPLES_DAILY_OUTPUT = ROOT / "outputs" / "peoples_daily"
PEOPLES_DAILY_TAGS = ("O", "B-PER", "I-PER", "B-ORG", "I-ORG", "B-LOC", "I-LOC")
PEOPLES_DAILY_TAG_TO_ID = {tag: i for i, tag in enumerate(PEOPLES_DAILY_TAGS)}
PEOPLES_DAILY_TYPES = {"PER", "ORG", "LOC"}
PEOPLES_DAILY_PROMPT = (
    "你是中文命名实体识别助手。只识别 PER(人名)、ORG(机构)、LOC(地点)。"
    '只输出 JSON：{"entities":[{"start":0,"end":2,"type":"PER","text":"姓名"}]}。'
    "start 从 0 开始，end 不包含实体末尾字符；偏移按原文字符计。"
    '没有实体时输出 {"entities":[]}。不要输出解释或 Markdown。'
)


def load_peoples_daily(split: str) -> list[dict]:
    """读取人民日报的 JSON 数组，并检查 token 与 BIO 标签逐位对齐。"""
    if split not in {"train", "validation", "test"}:
        raise ValueError(f"未知数据集划分: {split}")
    rows = json.loads((PEOPLES_DAILY_DIR / f"{split}.json").read_text(encoding="utf-8"))
    for i, row in enumerate(rows):
        if len(row["tokens"]) != len(row["ner_tags"]):
            raise ValueError(f"{split} 第 {i} 行 token 和标签长度不同")
    return rows


def select_peoples_daily(rows: list[dict], n: int, seed: int = 42) -> list[tuple[int, dict]]:
    """固定随机种子并按原始行号排序，四种方法共用完全相同的样本。"""
    if n < 0 or n >= len(rows):
        return list(enumerate(rows))
    return [(i, rows[i]) for i in sorted(random.Random(seed).sample(range(len(rows)), n))]


def peoples_daily_spans(tags: list[str]) -> set[tuple[int, int, str]]:
    """BIO 转成半开区间 (start, end, type)；异常 I 标签视作实体开头。"""
    spans = set()
    start, kind = None, None
    for i, tag in enumerate([*tags, "O"]):
        prefix, _, current = tag.partition("-")
        continuation = prefix == "I" and start is not None and current == kind
        if not continuation and start is not None:
            spans.add((start, i, kind))
            start, kind = None, None
        if prefix == "B" or (prefix == "I" and not continuation):
            start, kind = i, current
    return spans


def peoples_daily_gold(row: dict) -> set[tuple[int, int, str]]:
    return peoples_daily_spans(row["ner_tags"])


def peoples_daily_target(row: dict) -> str:
    """将 BIO 金标准转为生成式模型的监督目标。"""
    text = "".join(row["tokens"])
    entities = [dict(start=a, end=b, type=t, text=text[a:b])
                for a, b, t in sorted(peoples_daily_gold(row))]
    return json.dumps({"entities": entities}, ensure_ascii=False, separators=(",", ":"))


def parse_peoples_daily_entities(text: str, raw: str):
    """解析生成式输出；偏移错误时只根据原文文字修复，不查看金标准。"""
    import re
    match = re.search(r"\{.*\}", raw, re.S)
    if not match:
        return set(), "缺少 JSON 对象", 0
    try:
        obj = json.loads(match.group())
    except json.JSONDecodeError as exc:
        return set(), f"JSON 错误: {exc.msg}", 0
    entities = obj.get("entities") if isinstance(obj, dict) else None
    if not isinstance(entities, list):
        return set(), "entities 不是数组", 0
    found, repaired = set(), 0
    for entity in entities:
        if not isinstance(entity, dict) or entity.get("type") not in PEOPLES_DAILY_TYPES:
            continue
        surface = entity.get("text")
        if not isinstance(surface, str) or not surface:
            continue
        kind = entity["type"]
        start, end = entity.get("start"), entity.get("end")
        valid = (isinstance(start, int) and isinstance(end, int) and not isinstance(start, bool)
                 and 0 <= start < end <= len(text) and text[start:end] == surface)
        if not valid:
            positions = [m.start() for m in re.finditer(re.escape(surface), text)]
            positions = [p for p in positions if (p, p + len(surface), kind) not in found]
            if not positions:
                continue
            start = min(positions, key=lambda p: abs(p - (entity.get("start") if isinstance(entity.get("start"), int) else 0)))
            end = start + len(surface)
            repaired += 1
        found.add((start, end, kind))
    return found, None, repaired


def peoples_daily_metrics(golds: list[set], preds: list[set]) -> dict:
    """严格实体边界的 micro Precision、Recall、F1。"""
    tp = sum(len(g & p) for g, p in zip(golds, preds))
    predicted, gold = sum(map(len, preds)), sum(map(len, golds))
    precision = tp / predicted if predicted else 0.0
    recall = tp / gold if gold else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return dict(precision=precision, recall=recall, f1=f1, tp=tp, predicted=predicted, gold=gold)


def save_peoples_daily(name: str, obj: dict) -> Path:
    PEOPLES_DAILY_OUTPUT.mkdir(parents=True, exist_ok=True)
    path = PEOPLES_DAILY_OUTPUT / name
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def split_peoples_daily(row: dict, max_chars: int):
    """长句在实体外切段，保证训练和测试不丢失实体。"""
    tags = row["ner_tags"]
    start = 0
    while start < len(tags):
        end = min(start + max_chars, len(tags))
        while end < len(tags) and tags[end].startswith("I-") and end > start:
            end -= 1
        if end == start:
            end = min(start + max_chars, len(tags))
        yield start, row["tokens"][start:end], tags[start:end]
        start = end


class PeoplesDailyDataset(Dataset):
    """逐字分词并保留每个字符的首 token，供 BERT 与 CRF 共用。"""

    def __init__(self, selected, tokenizer, max_chars=192):
        self.examples = [(record_id, offset, tokens, tags)
                         for record_id, row in selected
                         for offset, tokens, tags in split_peoples_daily(row, max_chars)]
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, index):
        record_id, offset, tokens, tags = self.examples[index]
        encoded = self.tokenizer(tokens, is_split_into_words=True, truncation=True,
                                 max_length=512, add_special_tokens=True)
        previous, labels, first = None, [], []
        for word_id in encoded.word_ids():
            is_first = word_id is not None and word_id != previous
            first.append(is_first)
            labels.append(PEOPLES_DAILY_TAG_TO_ID[tags[word_id]] if is_first else -100)
            previous = word_id
        return dict(input_ids=encoded["input_ids"], attention_mask=encoded["attention_mask"],
                    first_mask=first, labels=labels, record_id=record_id, start=offset)


def collate_peoples_daily(tokenizer):
    """动态补齐 batch；-100 位置不参与交叉熵。"""
    def collate(batch):
        size = max(len(item["input_ids"]) for item in batch)
        result = {}
        for key, pad in (("input_ids", tokenizer.pad_token_id), ("attention_mask", 0),
                         ("first_mask", False), ("labels", -100)):
            result[key] = torch.tensor([item[key] + [pad] * (size - len(item[key])) for item in batch],
                                       dtype=torch.bool if key == "first_mask" else torch.long)
        result["record_id"] = [item["record_id"] for item in batch]
        result["start"] = [item["start"] for item in batch]
        return result
    return collate
