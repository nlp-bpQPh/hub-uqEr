"""
BertNER（线性头）和 BertCRFNER（CRF头）两个模型

教学重点：
  1. 线性头（BertNER）：每个 token 独立预测标签
     - 问题：softmax 的独立预测忽略标签间的依赖关系
     - 可能产生非法序列：B-name 后接 I-company，I-name 开头等

  2. CRF 层（BertCRFNER）：加入转移矩阵，全局最优解码
     - 转移矩阵学习"什么标签之后可以接什么标签"
     - Viterbi 算法保证输出合法序列，永远不会 B-name 后接 I-company
     - 代价：训练时需要前向-后向算法，比线性头慢约 20~30%

  3. 两者区别的量化：evaluate.py 会统计非法序列数

依赖：
  pip install pytorch-crf
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import transformers
from transformers import BertModel
from pathlib import Path
from transformers import AutoModel

from dataset import PEOPLES_DAILY_TAGS


def _load_bert(bert_path: str) -> BertModel:
    prev = transformers.logging.get_verbosity()
    transformers.logging.set_verbosity_error()
    bert = BertModel.from_pretrained(bert_path)
    transformers.logging.set_verbosity(prev)
    return bert


class BertNER(nn.Module):
    """BERT + 线性分类头，逐 token 独立预测 BIO 标签。

    前向过程：
      input_ids → BertModel → last_hidden_state (B, L, 768)
               → Dropout → Linear(768, num_labels) → logits (B, L, num_labels)

    损失：CrossEntropy，ignore_index=-100 跳过特殊token和非首子词
    预测：argmax(logits, dim=-1)
    """

    def __init__(self, bert_path: str, num_labels: int, dropout: float = 0.1):
        super().__init__()
        self.bert = _load_bert(bert_path)
        hidden_size = self.bert.config.hidden_size
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, num_labels)
        self.num_labels = num_labels

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor,
        labels: torch.Tensor = None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            return_dict=True,
        )
        seq_output = outputs.last_hidden_state  # (B, L, H)
        logits = self.classifier(self.dropout(seq_output))  # (B, L, num_labels)

        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits.view(-1, self.num_labels),
                labels.view(-1),
                ignore_index=-100,
            )
        return logits, loss


class BertCRFNER(nn.Module):
    """BERT + CRF 层，全局最优序列解码。

    与 BertNER 的区别：
      - Linear 输出称为 emissions（发射分数），不直接 argmax
      - CRF 在 emissions 上叠加转移矩阵，用 Viterbi 找全局最优序列
      - 损失：负对数似然（CRF 内部计算前向-后向）
      - 解码：self.crf.decode() 返回保证合法的标签序列

    CRF 的约束（自动学习）：
      - 初始只能以 O 或 B-X 开头
      - B-X 之后只能是 I-X 或 B-Y 或 O
      - I-X 之后只能是 I-X 或 B-Y 或 O
    """

    def __init__(self, bert_path: str, num_labels: int, dropout: float = 0.1):
        super().__init__()
        from torchcrf import CRF

        self.bert = _load_bert(bert_path)
        hidden_size = self.bert.config.hidden_size
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, num_labels)
        self.crf = CRF(num_labels, batch_first=True)
        self.num_labels = num_labels

    def _get_emissions(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor,
    ) -> torch.Tensor:
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            return_dict=True,
        )
        seq_output = outputs.last_hidden_state
        return self.classifier(self.dropout(seq_output))  # (B, L, num_labels)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor,
        labels: torch.Tensor = None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        emissions = self._get_emissions(input_ids, attention_mask, token_type_ids)
        mask = attention_mask.bool()  # CRF 要求 BoolTensor

        loss = None
        if labels is not None:
            # CRF 不支持 ignore_index，将 -100 替换为 0（PAD 位置被 mask 屏蔽，不影响梯度）
            labels_crf = labels.clone()
            labels_crf[labels_crf == -100] = 0
            # crf() 返回对数似然（正值），取负得到损失
            loss = -self.crf(emissions, labels_crf, mask=mask, reduction="mean")

        return emissions, loss

    def decode(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: torch.Tensor,
    ) -> list[list[int]]:
        """Viterbi 解码，返回 list[list[int]]，每条序列长度等于实际token数（不含PAD）。"""
        emissions = self._get_emissions(input_ids, attention_mask, token_type_ids)
        mask = attention_mask.bool()
        return self.crf.decode(emissions, mask=mask)


def build_model(
    use_crf: bool,
    bert_path: str,
    num_labels: int,
    dropout: float = 0.1,
) -> nn.Module:
    """模型工厂函数。"""
    model_cls = BertCRFNER if use_crf else BertNER
    model = model_cls(bert_path=bert_path, num_labels=num_labels, dropout=dropout)

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    model_name = "BERT + CRF" if use_crf else "BERT + Linear"
    print(f"模型：{model_name}")
    print(f"  标签数：{num_labels}")
    print(f"  参数总量：{total_params / 1e6:.1f}M")
    print(f"  可训练参数：{trainable_params / 1e6:.1f}M")
    return model


def resolve_peoples_daily_bert(model_name: str = "bert-base-chinese", allow_download: bool = False) -> str:
    """优先使用本机缓存，避免离线环境在 Hugging Face 上反复重试。"""
    path = Path(model_name)
    if path.exists():
        return str(path)
    if not allow_download:
        from huggingface_hub import try_to_load_from_cache
        config = try_to_load_from_cache(model_name, "config.json")
        if not isinstance(config, str):
            raise FileNotFoundError(f"本地没有 {model_name}；可加 --allow-download 下载")
        return str(Path(config).parent)
    return model_name


class ConstrainedCRF(nn.Module):
    """BIO 合法转移约束的线性链 CRF；实体标签顺序与已有 checkpoint 一致。"""

    def __init__(self, n_tags: int):
        super().__init__()
        self.start = nn.Parameter(torch.zeros(n_tags))
        self.end = nn.Parameter(torch.zeros(n_tags))
        self.transition = nn.Parameter(torch.zeros(n_tags, n_tags))
        start_penalty = torch.zeros(n_tags)
        transition_penalty = torch.zeros(n_tags, n_tags)
        for j, tag in enumerate(PEOPLES_DAILY_TAGS):
            if tag.startswith("I-"):
                start_penalty[j] = -10000
                for i, previous in enumerate(PEOPLES_DAILY_TAGS):
                    if previous not in ("B-" + tag[2:], "I-" + tag[2:]):
                        transition_penalty[i, j] = -10000
        self.register_buffer("start_penalty", start_penalty)
        self.register_buffer("transition_penalty", transition_penalty)

    def _scores(self):
        return self.start + self.start_penalty, self.transition + self.transition_penalty

    def loss(self, emissions, tags, mask):
        """前向算法计算配分函数；正确路径得分与其差值为负对数似然。"""
        start, transition = self._scores()
        batch, length, _ = emissions.shape
        alpha = start + emissions[:, 0]
        gold = start[tags[:, 0]] + emissions[torch.arange(batch, device=tags.device), 0, tags[:, 0]]
        for t in range(1, length):
            next_alpha = torch.logsumexp(alpha.unsqueeze(2) + transition.unsqueeze(0)
                                         + emissions[:, t].unsqueeze(1), dim=1)
            alpha = torch.where(mask[:, t].unsqueeze(1), next_alpha, alpha)
            step = transition[tags[:, t - 1], tags[:, t]] + emissions[
                torch.arange(batch, device=tags.device), t, tags[:, t]]
            gold = gold + step * mask[:, t]
        return (torch.logsumexp(alpha + self.end, dim=1) - gold
                - self.end[tags.gather(1, mask.long().sum(1).sub(1).unsqueeze(1)).squeeze(1)]).mean()

    def decode(self, emissions, mask):
        """Viterbi 找全局得分最高的合法 BIO 序列。"""
        start, transition = self._scores()
        score = start + emissions[:, 0]
        history = []
        for t in range(1, emissions.size(1)):
            candidates = score.unsqueeze(2) + transition.unsqueeze(0)
            best_score, previous = candidates.max(dim=1)
            score = torch.where(mask[:, t].unsqueeze(1), best_score + emissions[:, t], score)
            history.append(previous)
        last = (score + self.end).argmax(dim=1)
        paths = []
        for i, count in enumerate(mask.long().sum(1).tolist()):
            path = [last[i].item()]
            for t in range(count - 2, -1, -1):
                path.append(history[t][i, path[-1]].item())
            paths.append(path[::-1])
        return paths


class PeoplesDailyBertTagger(nn.Module):
    """人民日报 BERT 线性头与 BERT+CRF 共用编码器和分类头。"""

    def __init__(self, model_name="bert-base-chinese", use_crf=False, allow_download=False):
        super().__init__()
        self.bert = AutoModel.from_pretrained(resolve_peoples_daily_bert(model_name, allow_download))
        self.dropout = nn.Dropout(0.1)
        self.head = nn.Linear(self.bert.config.hidden_size, len(PEOPLES_DAILY_TAGS))
        self.crf = ConstrainedCRF(len(PEOPLES_DAILY_TAGS)) if use_crf else None

    def forward(self, input_ids, attention_mask, first_mask, labels=None):
        states = self.bert(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        logits = self.head(self.dropout(states))
        if self.crf is None:
            loss = F.cross_entropy(logits.reshape(-1, len(PEOPLES_DAILY_TAGS)),
                                   labels.reshape(-1), ignore_index=-100) if labels is not None else None
            return loss, logits
        lengths = first_mask.long().sum(1)
        longest = int(lengths.max().item())
        emissions = logits.new_zeros((len(logits), longest, len(PEOPLES_DAILY_TAGS)))
        compact_mask = torch.arange(longest, device=logits.device)[None, :] < lengths[:, None]
        compact_labels = torch.zeros((len(logits), longest), dtype=torch.long, device=logits.device)
        for i in range(len(logits)):
            count = int(lengths[i])
            emissions[i, :count] = logits[i, first_mask[i]]
            if labels is not None:
                compact_labels[i, :count] = labels[i, first_mask[i]]
        loss = self.crf.loss(emissions, compact_labels, compact_mask) if labels is not None else None
        return loss, (emissions, compact_mask)
