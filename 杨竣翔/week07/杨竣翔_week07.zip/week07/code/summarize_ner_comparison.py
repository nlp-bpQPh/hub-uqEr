"""核验 NER 逐句预测，生成图表与实验报告。"""

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager, ticker
import numpy as np

from run_ner_comparison import ENTITY_TYPES, METHODS, NER, ROOT, write_json
from dataset import load_peoples_daily, peoples_daily_gold, peoples_daily_metrics

FULL = "完整测试集"
SUBSET = "原实验的 100 句"
TYPES = {"PER": "人名 PER", "ORG": "机构名 ORG", "LOC": "地名 LOC"}
ORDER = ("bilstm_crf", "bert_linear", "roberta_linear", "bert_crf", "roberta_crf")
HISTORICAL = {
    "deepseek_api": ("DeepSeek API 零样本", "deepseek_api_progress.json"),
    "qwen_lora": ("Qwen2-0.5B + LoRA", "qwen_lora_progress.json"),
}
COLORS = ("#356092", "#24877a", "#b96d38")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_predictions(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def metrics_from_predictions(rows):
    """用实体坐标重新计算指标，避免作图时误读其他划分的结果。"""
    gold = [set(map(tuple, row["gold"])) for row in rows]
    preds = [set(map(tuple, row["predicted"])) for row in rows]
    return peoples_daily_metrics(gold, preds)


def load_results(output):
    protocol = read_json(output / "experiment_config.json")
    test_ids = protocol["ids"]["test"]
    subset_ids = protocol["legacy_test_ids"]
    subset_keys = set(subset_ids)
    test_rows = load_peoples_daily("test")
    test_gold = [set(peoples_daily_gold(test_rows[i])) for i in test_ids]
    results, predictions = {}, {}
    for method in ORDER:
        result = read_json(output / "metrics" / f"{method}.json")
        rows = read_predictions(output / "predictions" / f"{method}.jsonl")
        subset = [row for row in rows if row["id"] in subset_keys]
        if (result["protocol_sha256"] != protocol["sha256"] or
                [row["id"] for row in rows] != test_ids or
                [row["id"] for row in subset] != subset_ids or
                [set(map(tuple, row["gold"])) for row in rows] != test_gold or
                metrics_from_predictions(rows) != result["full_test"]["micro"] or
                metrics_from_predictions(subset) != result["legacy_test"]["micro"]):
            raise ValueError(f"{method} 的预测、样本编号或分数不一致")
        for kind in ENTITY_TYPES:
            typed_rows = [{key: [e for e in row[key] if e[2] == kind]
                           for key in ("gold", "predicted")} for row in rows]
            if metrics_from_predictions(typed_rows) != result["full_test"]["by_type"][kind]:
                raise ValueError(f"{method} 的 {kind} 指标与预测不一致")
        if result["decoder"] == "CRF" and result["full_test"]["illegal_bio"]["illegal_seqs"] != 0:
            raise ValueError(f"{method} 出现非法 BIO 序列")
        predictions[method] = rows
        results[method] = result
    # 生成式方法的历史缓存必须覆盖同一批句子，并能重算出原报告的分数。
    reference = NER / "outputs" / "peoples_daily"
    gold_by_id = {row["id"]: row["gold"] for row in predictions["bert_linear"]}
    historical = {}
    for method, (label, name) in HISTORICAL.items():
        saved = read_json(reference / f"eval_{method}.json")
        cached = read_json(reference / name)
        if (saved["sample_ids"] != subset_ids or cached["sample_ids"] != subset_ids or
                saved["status"] != "completed" or saved["split"] != "test"):
            raise ValueError(f"{method} 的历史样本编号与当前子集不一致")
        rows = [{"gold": gold_by_id[i], "predicted": cached["details"][str(i)]["pred"]}
                for i in subset_ids]
        if metrics_from_predictions(rows) != saved["metrics"]:
            raise ValueError(f"{method} 的历史预测与已存指标不一致")
        historical[method] = {**saved, "label": label}
    return protocol, results, predictions, historical


def paired_changes(predictions, seed):
    """从测试句子成对重采样，计算替换编码器前后的 F1 差值区间。"""
    rng = np.random.default_rng(seed)
    comparisons = {}
    for decoder in ("linear", "crf"):
        first, second = [predictions[f"{encoder}_{decoder}"] for encoder in ("bert", "roberta")]
        counts = []
        for base, new in zip(first, second, strict=True):
            if base["id"] != new["id"] or base["gold"] != new["gold"]:
                raise ValueError("编码器对照的逐句金标不一致")
            gold = set(map(tuple, base["gold"]))
            entities = [set(map(tuple, row["predicted"])) for row in (base, new)]
            counts.append([len(gold), *(n for pred in entities for n in (len(gold & pred), len(pred)))])
        counts = np.asarray(counts)

        def difference(totals):
            gold, tp_bert, n_bert, tp_new, n_new = totals.T
            return 2 * tp_new / (gold + n_new) - 2 * tp_bert / (gold + n_bert)

        differences = []
        for _ in range(40):
            samples = rng.integers(len(counts), size=(100, len(counts)))
            differences.extend(difference(counts[samples].sum(axis=1)))
        comparisons[decoder] = {
            "difference": float(difference(counts.sum(0))),
            "ci95": np.quantile(differences, [0.025, 0.975]).tolist(),
            "bootstrap_repetitions": len(differences),
        }
    return comparisons


def save_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def configure_style():
    font = Path("C:/Windows/Fonts/msyh.ttc")
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=font).get_name()
    plt.rcParams.update({"axes.unicode_minus": False, "axes.spines.top": False,
                         "axes.spines.right": False, "axes.edgecolor": "#bec8d1",
                         "text.color": "#172c44", "axes.labelcolor": "#172c44",
                         "xtick.color": "#374c60", "ytick.color": "#172c44"})


def chart(output, filename, title, subtitle, labels, series):
    """所有横向分组图共用比例尺，柱端标明实测百分比。"""
    fig, ax = plt.subplots(figsize=(10.8, 2.15 + len(labels) * 0.71))
    fig.subplots_adjust(left=0.25, right=0.95, top=0.76, bottom=0.13)
    fig.text(0.045, 0.945, title, fontsize=20, fontweight="bold", va="top")
    fig.text(0.046, 0.867, subtitle, fontsize=10.5, color="#506678", va="top")
    y = np.arange(len(labels))
    width = 0.22
    for j, (name, values) in enumerate(series.items()):
        bars = ax.barh(y + (j - 1) * width, values, height=width * 0.84, color=COLORS[j], label=name)
        ax.bar_label(bars, [f"{v:.1%}" for v in values], fontsize=8.5, padding=4, color="#233e57")
    ax.set_yticks(y, labels, fontsize=10)
    ax.invert_yaxis()
    ax.set_xlim(0, 1.075)
    ax.set_xticks(np.linspace(0, 1, 6))
    ax.xaxis.set_major_formatter(ticker.PercentFormatter(1, decimals=0))
    ax.set_axisbelow(True)
    ax.grid(axis="x", color="#e5ebf1")
    ax.tick_params(axis="y", length=0, pad=8)
    ax.legend(loc="lower left", bbox_to_anchor=(0, 1.01), ncols=3, frameon=False, fontsize=9,
              borderaxespad=0)
    fig.savefig(output / filename, dpi=180, facecolor="white")
    plt.close(fig)


def training_chart(output, results):
    """训练曲线沿用选模指标，图右展示测试集解码的 BIO 合法性。"""
    fig, (ax, bio) = plt.subplots(1, 2, figsize=(11.5, 5), gridspec_kw={"width_ratios": [1.1, 1]})
    fig.subplots_adjust(left=0.10, right=0.95, top=0.77, bottom=0.26, wspace=0.60)
    fig.text(0.045, 0.948, "验证集 F1 与测试集 BIO 合法性", fontsize=20, fontweight="bold", va="top")
    fig.text(0.046, 0.855, "按验证集实体 F1 选模 · 统计完整测试句的原始 BIO 输出",
             fontsize=10.5, color="#506678", va="top")
    for method in ORDER:
        result = results[method]
        history = result["history"]
        family = method.split("_")[0]
        color = COLORS[("bert", "roberta", "bilstm").index(family)]
        ax.plot([r["epoch"] for r in history], [r["validation"]["f1"] for r in history],
                marker="o", linestyle="-" if result["decoder"] == "CRF" else "--", linewidth=1.9,
                color=color, label=result["label"])
    ax.set_xlabel("训练轮次")
    ax.set_ylabel("验证集实体级 F1")
    ax.set_ylim(0, 1)
    ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
    ax.yaxis.set_major_formatter(ticker.PercentFormatter(1))
    ax.grid(axis="y", color="#e5ebf1")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.20), ncols=2, frameon=False, fontsize=8)
    rates = [r["full_test"]["illegal_bio"]["illegal_seq_rate"] for r in results.values()]
    bars = bio.barh(np.arange(len(ORDER)), rates, height=0.51, color="#b96d38")
    bio.bar_label(bars, [f"{v:.2%}" for v in rates], padding=4, fontsize=9)
    bio.set_yticks(np.arange(len(ORDER)), [METHODS[m][0] for m in ORDER], fontsize=8)
    bio.invert_yaxis()
    bio.set_xlim(0, max(max(rates), 0.01) * 1.31)
    bio.xaxis.set_major_formatter(ticker.PercentFormatter(1, decimals=1))
    bio.set_xlabel("至少一处非法转移的句子比例")
    bio.set_axisbelow(True)
    bio.grid(axis="x", color="#e5ebf1")
    fig.savefig(output / "04_验证曲线与BIO合法性.png", dpi=180, facecolor="white")
    plt.close(fig)


def write_report(output, protocol, results, historical, changes):
    counts = [len(protocol["ids"][s]) for s in ("train", "validation", "test")]
    n_train, n_val, n_test = (f"{n:,}" for n in counts)
    gold = results["bert_linear"]["full_test"]["micro"]["gold"]
    lines = [
        "# 第七周 NER 预训练模型对照实验", "",
        f"使用人民日报 NER 的人名（PER）、机构名（ORG）和地名（LOC）标注。以 seed={protocol['seed']} "
        f"固定抽取 {n_train} 句训练、{n_val} 句验证，在完整测试集 {n_test} 句的 {gold:,} 个金标准实体上评估。",
        f"预训练权重使用本地 `bert-base-chinese` 和 `{Path(protocol['roberta_path']).as_posix()}`。"
        "编码器、CRF 和 BIO 约束复用 WEEK07 课件，NER 标签与实体评分复用同周的序列标注项目。",
        "",
        "以原文字符半开区间 `(start, end)` 和实体类别严格匹配计分，汇报实体级 micro Precision、Recall、F1。"
        "训练窗口在实体外切分。验证和测试仅按原文长度建立重叠窗口，平均重叠处的发射分数，再恢复整句标签。"
        "线性头逐字符取最高分，遇到无合法前驱的 `I-X` 时按新实体起点解析。CRF 通过 BIO 硬约束和维特比解码产生整句标签。",
        "",
        f"所有方法使用同一批训练和验证样本、每批 {protocol['batch_size']}、训练 {protocol['epochs']} 轮，"
        f"按验证集实体 F1 选模。BERT 与 RoBERTa 均全参数微调，编码器学习率 2e-5，标注头学习率 1e-4。"
        "课件 BiLSTM + CRF 从随机权重训练，学习率 1e-3。它用于参照这组训练预算下无预训练的表现。",
        "", "## 完整测试集", "",
        "| 方法 | Precision | Recall | F1 | PER F1 | ORG F1 | LOC F1 | 最佳轮次 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for result in results.values():
        values = result["full_test"]
        metrics = values["micro"]
        scores = [metrics[k] for k in ("precision", "recall", "f1")]
        scores += [values["by_type"][kind]["f1"] for kind in ENTITY_TYPES]
        lines.append(f"| {result['label']} | " + " | ".join(f"{score:.2%}" for score in scores) +
                     f" | {result['best_epoch']} |")
    lines += ["", "[整体指标图](01_完整测试集对比.png) · [分实体类别 F1 图](02_分实体类别F1.png) · "
              "[验证曲线与 BIO 合法性](04_验证曲线与BIO合法性.png)", "",
              "## 更换预训练编码器的影响", "",
              "| 相同解码头 | RoBERTa 相对 BERT 的 F1 变化（百分点） | 按句配对重采样 95% 区间（百分点） |",
              "| --- | ---: | ---: |"]
    for decoder, change in changes.items():
        low, high = change["ci95"]
        lines.append(f"| {'CRF' if decoder == 'crf' else 'Linear'} | {100 * change['difference']:+.2f} | "
                     f"[{100 * low:+.2f}, {100 * high:+.2f}] |")
    best = max(results.values(), key=lambda r: r["full_test"]["micro"]["f1"])
    crf_gain = {family: results[f"{family}_crf"]["full_test"]["micro"]["f1"] -
                results[f"{family}_linear"]["full_test"]["micro"]["f1"] for family in ("bert", "roberta")}
    lines += ["", f"完整测试集上 {best['label']} 的 F1 最高，为 {best['full_test']['micro']['f1']:.2%}。"
              f"在相同预训练编码器上，CRF 将 BERT 和 RoBERTa 的 F1 分别提高 {100 * crf_gain['bert']:.2f} "
              f"和 {100 * crf_gain['roberta']:.2f} 个百分点。", "",
              "差值基于未四舍五入的 F1。区间来自 4,000 次测试句配对重采样，反映本次模型在测试样本上的波动。"
              "每种方法训练使用同一个随机种子，区间未涵盖重新训练的随机性。", "",
              "## 原实验的 100 句对照", "",
              "下表的五个本次训练方法来自完整测试集预测中的同一批 100 句。DeepSeek 与 Qwen 使用经过逐句核对的原实验缓存。"
              "DeepSeek 为零样本，Qwen LoRA 以 2,000 句训练 1 轮，生成式输出按原文定位文本偏移。表中的训练预算和推理方式各有差异。",
              "", "| 方法 | 来源 | Precision | Recall | F1 |", "| --- | --- | ---: | ---: | ---: |"]
    for result, micro, source in [(r, r["legacy_test"]["micro"], "本次实测") for r in results.values()] + [
            (r, r["metrics"], "原实验缓存") for r in historical.values()]:
        values = " | ".join(f"{micro[k]:.2%}" for k in ("precision", "recall", "f1"))
        lines.append(f"| {result['label']} | {source} | {values} |")
    lines += ["", "[100 句对照图](03_原实验同样本对比.png) · [全部指标 CSV](metrics_summary.csv) · "
              "[样本编号及运行设置](experiment_config.json)", "", "## 复现", "",
              "在解压得到的 `week07` 目录执行前两条命令可用已保存的预测重绘图表。",
              "重新训练时，将命令中的 RoBERTa 路径改为本机目录，并把 `bert-base-chinese` 权重放入 Hugging Face 缓存。",
              "语料来源为 Chinese-NLP-Corpus 的人民日报 NER。",
              "[数据来源](https://github.com/OYE93/Chinese-NLP-Corpus/tree/master/NER/People%27s%20Daily)", "",
              "```powershell",
              "python -m pip install -r code/requirements.txt",
              "python code/summarize_ner_comparison.py",
              "python code/run_ner_comparison.py --roberta D:/model/RoBERTa-Chinese-base --result-dir rerun",
              "python code/summarize_ner_comparison.py --result-dir rerun",
              "```", ""]
    (output / "实验报告.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-dir", type=Path, default=ROOT / "result")
    output = parser.parse_args().result_dir.resolve()
    protocol, results, predictions, historical = load_results(output)
    changes = paired_changes(predictions, protocol["seed"])
    full = {r["label"]: r["full_test"]["micro"] for r in results.values()}
    subset = {r["label"]: r["legacy_test"]["micro"] for r in results.values()}
    subset.update({r["label"] + "（原记录）": r["metrics"] for r in historical.values()})
    by_type = {TYPES[k]: [r["full_test"]["by_type"][k]["f1"] for r in results.values()] for k in ENTITY_TYPES}
    indicators = {"Precision": "precision", "Recall": "recall", "F1": "f1"}
    configure_style()
    for data, title, subtitle, filename in (
            (full, "完整测试集的实体识别指标", f"{len(protocol['ids']['test']):,} 句 · 实体类别与字符边界严格匹配",
             "01_完整测试集对比.png"),
            (subset, "原实验同样本的实体识别指标", "相同的 100 句 · DeepSeek 和 Qwen 使用历史缓存",
             "03_原实验同样本对比.png")):
        chart(output, filename, title, subtitle, list(data),
              {name: [m[key] for m in data.values()] for name, key in indicators.items()})
    chart(output, "02_分实体类别F1.png", "各实体类别的 F1", "完整测试集 · 按实体类别独立计分",
          list(full), by_type)
    training_chart(output, results)
    rows = []
    for split, key in ((FULL, "full_test"), (SUBSET, "legacy_test")):
        for result in results.values():
            metrics = result[key]
            for group, values in [("micro", metrics["micro"]), *metrics["by_type"].items()]:
                rows.append({"split": split, "method": result["label"], "source": "本次实测",
                             "entity_type": group, "sentences": metrics["sentences"], **values})
    for result in historical.values():
        rows.append({"split": SUBSET, "method": result["label"], "source": "原实验缓存",
                     "entity_type": "micro", "sentences": len(result["sample_ids"]), **result["metrics"]})
    save_csv(output / "metrics_summary.csv", rows)
    write_json(output / "paired_comparison.json", changes)
    write_report(output, protocol, results, historical, changes)
    print(f"已校验五个方法的逐句预测和两个已有方法的指标。图表保存在 {output}")


if __name__ == "__main__":
    main()
