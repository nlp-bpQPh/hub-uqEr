"""从逐条预测重建表格、论文式静态图和中文实验报告，不运行任何训练。"""

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np

ORDER = ["rule", "tfidf", "bert_history", "qwen_zero_history", "qwen_lora_history",
         "qwen_full_history", "api_history", "roberta_frozen", "roberta_full"]
BLUE, TEAL, ORANGE = "#2463A6", "#178781", "#E19236"


def setup():
    plt.rcParams.update({
        "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
        "axes.unicode_minus": False, "font.size": 11,
        "axes.spines.top": False, "axes.spines.right": False,
        "figure.facecolor": "#FFFFFF", "axes.facecolor": "#FFFFFF",
        "savefig.facecolor": "#FFFFFF", "svg.fonttype": "none",
    })


def load_results(out):
    by_key = {p.stem: json.loads(p.read_text(encoding="utf-8"))
              for p in (out / "predictions").glob("*.json")}
    rows = [by_key[k] for k in ORDER if k in by_key]
    assert rows, "没有预测结果，请先运行 run_experiments.py"
    assert len({d["sample_sha256"] for d in rows}) == 1, "发现评测样本不一致"
    assert all(d["report"]["n_eval"] == len(d["preds"]) for d in rows)
    reference = [(p["text"], p["true"]) for p in rows[0]["preds"]]
    assert all([(p["text"], p["true"]) for p in d["preds"]] == reference for d in rows)
    return rows, by_key


def save(fig, out, name):
    fig.savefig(out / f"{name}.png", dpi=190, bbox_inches="tight")
    fig.savefig(out / f"{name}.svg", bbox_inches="tight")
    plt.close(fig)


def overview(rows, out):
    fig, ax = plt.subplots(figsize=(13, 7.5))
    y = np.arange(len(rows))
    for offset, field, color, label in [(-0.18, "accuracy", BLUE, "准确率"),
                                          (0.18, "macro_f1", TEAL, "Macro-F1")]:
        bars = ax.barh(y + offset, [d["report"][field] for d in rows], height=0.31,
                       color=color, label=label)
        for b, d in zip(bars, rows):
            if d["key"].endswith("history"):
                b.set_hatch("///")
                b.set_edgecolor("white")
            ax.text(b.get_width() + 0.008, b.get_y() + b.get_height()/2,
                    f"{b.get_width():.1%}", va="center", fontsize=10)
    ax.set_yticks(y, [d["name"] + ("  [历史]" if d["key"].endswith("history") else "  [本次]") for d in rows])
    ax.invert_yaxis()
    ax.set_xlim(0, min(1.0, max(d["report"]["accuracy"] for d in rows) + 0.13))
    ax.xaxis.set_major_formatter(PercentFormatter(1))
    ax.grid(axis="x", alpha=0.18)
    ax.set_axisbelow(True)
    ax.legend(loc="lower right", frameon=False)
    ax.set_title("第六周分类方法对比：更换为 RoBERTa-Chinese-base", loc="left", fontsize=17, pad=20)
    fig.text(0.02, 0.015, "同一批 500 条去重评测样本 · seed=42 · 15 类固定口径 · 解析失败计错\n斜线柱为课程历史预测复核；历史模型未重新训练，训练预算与选模流程不同。", fontsize=10, color="#555555")
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    save(fig, out, "01_各方法指标对比")


def per_class(by_key, out):
    keys = [k for k in ["tfidf", "bert_history", "roberta_frozen", "roberta_full"] if k in by_key]
    if not keys:
        return
    labels = [p["label"] for p in by_key[keys[0]]["report"]["per_class"]]
    support = [p["support"] for p in by_key[keys[0]]["report"]["per_class"]]
    matrix = np.array([[p["f1"] for p in by_key[k]["report"]["per_class"]] for k in keys]).T
    fig, ax = plt.subplots(figsize=(10.5, 8.5))
    im = ax.imshow(matrix, cmap="Blues", vmin=0, vmax=1, aspect="auto")
    ax.set_yticks(range(15), [f"{name}  (n={n})" for name, n in zip(labels, support)])
    ax.set_xticks(range(len(keys)), [by_key[k]["name"].replace(" + ", "\n+ ") + ("\n[历史]" if k.endswith("history") else "\n[本次]") for k in keys])
    for i in range(15):
        for j in range(len(keys)):
            ax.text(j, i, f"{matrix[i,j]:.1%}", ha="center", va="center",
                    color="white" if matrix[i,j] > 0.58 else "#15283A")
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.04, format=PercentFormatter(1), label="类别 F1")
    ax.set_title("各类别 F1：观察更换模型后的具体变化", fontsize=16, pad=18)
    fig.tight_layout()
    save(fig, out, "02_逐类别F1对比")


def confusion(by_key, out):
    if "roberta_full" not in by_key:
        return
    row = by_key["roberta_full"]
    matrix = np.array(row["report"]["confusion_matrix"])[:, :15]
    labels = [p["label"] for p in row["report"]["per_class"]]
    norm = matrix / np.maximum(matrix.sum(1, keepdims=True), 1)
    fig, ax = plt.subplots(figsize=(12, 10))
    im = ax.imshow(norm, vmin=0, vmax=1, cmap="Blues")
    ax.set_xticks(range(15), labels, rotation=45, ha="right")
    ax.set_yticks(range(15), labels)
    for i in range(15):
        for j in range(15):
            if matrix[i,j]:
                ax.text(j, i, str(matrix[i,j]), ha="center", va="center", fontsize=9,
                        color="white" if norm[i,j] > 0.55 else "#203245")
    ax.set_xlabel("预测类别")
    ax.set_ylabel("真实类别")
    ax.set_title("RoBERTa 全量微调：混淆矩阵", fontsize=17, pad=18)
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.03, format=PercentFormatter(1), label="按真实类别归一化")
    fig.text(0.12, 0.02, "格内数字为样本数；颜色为每个真实类别内的比例。", color="#555555")
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save(fig, out, "03_RoBERTa混淆矩阵")


def learning_curve(by_key, out):
    if "roberta_full" not in by_key:
        return
    row = by_key["roberta_full"]
    history = row["history"]
    x = [d["epoch"] for d in history]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    axes[0].plot(x, [d["train_loss"] for d in history], "o-", color=BLUE, linewidth=2.2)
    axes[0].set_ylabel("训练集平均加权交叉熵")
    axes[0].set_title("训练损失")
    for field, label, color in [("dev_accuracy", "Dev Accuracy", BLUE), ("dev_macro_f1", "Dev Macro-F1", TEAL)]:
        axes[1].plot(x, [d[field] for d in history], "o-", color=color, label=label, linewidth=2.2)
    axes[1].axvline(row["best_epoch"], color=ORANGE, linestyle="--", label=f"选择第 {row['best_epoch']} 轮")
    axes[1].set_title("独立 1,000 条 dev 样本选模")
    axes[1].yaxis.set_major_formatter(PercentFormatter(1))
    axes[1].legend(frameon=False)
    for ax in axes:
        ax.set_xticks(x)
        ax.set_xlabel("Epoch")
        ax.grid(alpha=0.2)
    fig.suptitle("RoBERTa 训练过程：最终 500 条评测样本不参与选模", fontsize=16)
    fig.tight_layout()
    save(fig, out, "04_RoBERTa训练曲线")


def efficiency(rows, out):
    current = [d for d in rows if d["source"] == "本次实测" and d.get("fit_seconds", 0) > 0]
    if not current:
        return
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5))
    colors = [BLUE, ORANGE, TEAL]
    for row, color in zip(current, colors):
        axes[0].scatter(row["fit_seconds"], row["report"]["macro_f1"], s=115, color=color, label=row["name"])
        axes[0].annotate(f"{row['fit_seconds']:.0f}s / {row['report']['macro_f1']:.1%}",
                         (row["fit_seconds"], row["report"]["macro_f1"]), xytext=(5, 9), textcoords="offset points", fontsize=9)
    axes[0].set_xscale("log")
    axes[0].margins(x=0.35, y=0.35)
    axes[0].set_xlabel("拟合耗时 / 秒（对数刻度）")
    axes[0].set_ylabel("Macro-F1")
    axes[0].yaxis.set_major_formatter(PercentFormatter(1))
    axes[0].grid(alpha=0.18)
    axes[0].legend(loc="best", frameon=False, fontsize=9)
    ms = [d["inference_seconds"] * 1000 / d["report"]["n_eval"] for d in current]
    bars = axes[1].barh(range(len(current)), ms, color=colors[:len(current)])
    axes[1].set_yticks(range(len(current)), [d["name"].replace(" + ", "\n+ ") for d in current])
    axes[1].set_xlabel("批量推理平均毫秒 / 条")
    axes[1].set_xlim(0, max(ms) * 1.3)
    for b, value in zip(bars, ms):
        axes[1].text(value + max(ms)*0.025, b.get_y()+b.get_height()/2, f"{value:.2f}", va="center")
    axes[1].grid(axis="x", alpha=0.18)
    axes[1].set_axisbelow(True)
    fig.suptitle("本次实测方法：分类效果与运行成本", fontsize=16)
    fig.text(0.02, 0.015, "拟合耗时含特征提取或各轮 dev 验证；不含模型加载。神经模型输入已分词、batch=64、FP16；不是端到端单条延迟。", fontsize=9, color="#555555")
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save(fig, out, "05_本次实测效率对比")


def paired_analysis(by_key, out):
    if not {"bert_history", "roberta_full"} <= by_key.keys():
        return None
    bert, roberta = by_key["bert_history"], by_key["roberta_full"]
    y = np.array([p["true"] for p in bert["preds"]])
    old = np.array([p["pred"] for p in bert["preds"]]) == y
    new = np.array([p["pred"] for p in roberta["preds"]]) == y
    both_right, only_old = int((old & new).sum()), int((old & ~new).sum())
    only_new, both_wrong = int((~old & new).sum()), int((~old & ~new).sum())
    rng = np.random.default_rng(42)
    delta = new.astype(float) - old.astype(float)
    bootstrap = delta[rng.integers(0, len(y), size=(10000, len(y)))].mean(1)
    low, high = np.quantile(bootstrap, [0.025, 0.975])
    result = {"both_correct": both_right, "only_bert_correct": only_old,
              "only_roberta_correct": only_new, "both_wrong": both_wrong,
              "accuracy_difference": float(delta.mean()), "paired_bootstrap_95_ci": [float(low), float(high)],
              "bootstrap_iterations": 10000,
              "interpretation": "只刻画这 500 条样本的抽样波动，不包含重训随机性，且历史 BERT 的选模流程不同"}
    (out / "paired_comparison.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    fig, ax = plt.subplots(figsize=(7.5, 5.7))
    matrix = np.array([[both_right, only_old], [only_new, both_wrong]])
    ax.imshow(matrix, cmap="Blues", vmin=0, vmax=max(matrix.max(), 1))
    ax.set_xticks([0, 1], ["RoBERTa 正确", "RoBERTa 错误"])
    ax.set_yticks([0, 1], ["BERT 正确", "BERT 错误"])
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{matrix[i,j]} 条\n{matrix[i,j]/len(y):.1%}", ha="center", va="center", fontsize=17,
                    color="white" if matrix[i,j] > matrix.max()*0.55 else "#172B40")
    ax.set_title("相同样本上的预测变化：历史 BERT → RoBERTa", fontsize=14, pad=20)
    fig.text(0.05, 0.02, f"准确率差值 {delta.mean()*100:+.2f} 个百分点；配对 Bootstrap 95% 区间 [{low*100:+.2f}, {high*100:+.2f}]\n仅反映评测样本波动；不能替代相同选模流程下的多随机种子实验。", fontsize=9, color="#555555")
    fig.tight_layout(rect=(0, 0.09, 1, 1))
    save(fig, out, "06_与原BERT预测变化")
    return result


def export_tables(rows, out):
    fields = ["method", "source", "accuracy", "macro_f1", "weighted_f1", "used_classes", "unparsed",
              "n_eval", "fit_seconds", "inference_ms_per_sample", "sample_sha256"]
    with (out / "metrics_summary.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            r = row["report"]
            writer.writerow({"method": row["name"], "source": row["source"],
                **{k: r[k] for k in fields[2:8]}, "fit_seconds": row.get("fit_seconds"),
                "inference_ms_per_sample": row["inference_seconds"] * 1000 / r["n_eval"] if row.get("inference_seconds") is not None else None,
                "sample_sha256": row["sample_sha256"]})
    with (out / "per_class_metrics.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["method", "source", "label", "precision", "recall", "f1", "support"])
        writer.writeheader()
        for row in rows:
            for p in row["report"]["per_class"]:
                writer.writerow({"method": row["name"], "source": row["source"], **p})
    (out / "metrics_summary.json").write_text(json.dumps([
        {k: v for k, v in row.items() if k not in ["preds", "original_report"]} for row in rows
    ], ensure_ascii=False, indent=2), encoding="utf-8")


def write_report(rows, by_key, paired, out):
    config = json.loads((out / "experiment_config.json").read_text(encoding="utf-8"))
    protocol = config["data"]
    lines = ["# 第六周作业：更换预训练模型的分类对比实验", "",
             "## 任务与实现", "",
             "基于课程 WEEK06/code 的 TNEWS 数据、标签顺序、关键词规则、TF-IDF 设置和 BertClassifier 分类结构，"
             "将神经分类模型的预训练主干更换为 `D:/model/RoBERTa-Chinese-base`。新代码位于 `code/comparison/`，中文注释解释关键步骤。", "",
             "本次实际运行四种方法：规则、TF-IDF + SVM、RoBERTa 冻结均值特征 + SVM、RoBERTa 全量微调。"
             "另外复核课程提供的 BERT、Qwen3 零样本、Qwen3 LoRA、Qwen3 全量微调与 API 零样本逐条预测。"
             "本地没有原 bert-base-chinese、Qwen3-0.6B 权重和对应训练 checkpoint，因此五项明确标记为历史结果；没有重新调用 API。", "",
             "## 数据与公平性", "",
             f"- 原训练集 {protocol['n_train']:,} 条，原验证集 {protocol['n_val_original']:,} 条；移除与训练标题完全重叠的 {protocol['n_removed_overlap']:,} 条后剩 {protocol['n_clean']:,} 条。",
             f"- 沿用课程 `sample_subset(clean_val, 500, seed=42)` 的 {protocol['n_eval']} 条评测样本，历史预测的文本、真实标签、顺序均逐条核对。",
             f"- 从其余干净样本另抽 {protocol['n_dev']:,} 条 dev（seed=43），并排除全部评测标题，只用 dev Macro-F1 选最佳轮次。训练 / dev / 评测标题无交集。",
             "- 所有模型使用相同 15 类重新计算 Accuracy、Macro-F1、Weighted-F1；生成模型解析失败 -1 计为答错，也留在 F1 的真实类别分母中。",
             "- 课程原 BERT 的训练脚本使用完整原验证集选模，其中包含这 500 条；本次 RoBERTa 则将其隔离。历史模型还有训练样本数、随机性和预算差异，因此横向表是参考性对比，不能把差异完全归因于预训练主干。",
             f"- 评测样本 SHA-256：`{protocol['evaluation_sha256']}`。", "",
             "## 结果", "",
             "| 方法 | 来源 | Accuracy | Macro-F1 | Weighted-F1 | 覆盖类 | 失败数 |",
             "|---|---|---:|---:|---:|---:|---:|"]
    for d in rows:
        r = d["report"]
        lines.append(f"| {d['name']} | {'本次实测' if d['source']=='本次实测' else '课程历史复核'} | {r['accuracy']:.2%} | {r['macro_f1']:.2%} | {r['weighted_f1']:.2%} | {r['used_classes']}/15 | {r['unparsed']} |")
    if "roberta_full" in by_key:
        row = by_key["roberta_full"]
        r, old = row["report"], by_key.get("bert_history", {}).get("report")
        lines += ["", "## 结果分析", "",
                  f"RoBERTa 全量微调 Accuracy 为 **{r['accuracy']:.2%}**，Macro-F1 为 **{r['macro_f1']:.2%}**；"
                  f"最佳 checkpoint 为第 **{row['best_epoch']}** 轮，独立 dev Macro-F1={row['dev_macro_f1']:.4f}。"]
        if old:
            lines += ["", f"相对历史 BERT，Accuracy 变化 **{(r['accuracy']-old['accuracy'])*100:+.2f} 个百分点**，"
                      f"Macro-F1 变化 **{(r['macro_f1']-old['macro_f1'])*100:+.2f} 个百分点**。"]
        for key in ["tfidf", "roberta_frozen"]:
            if key in by_key:
                b = by_key[key]
                lines += ["", f"相对本次 {b['name']}，全量微调 Macro-F1 变化 {(r['macro_f1']-b['report']['macro_f1'])*100:+.2f} 个百分点。"]
        current = [d for d in rows if d["source"] == "本次实测"]
        winner = max(current, key=lambda d: d["report"]["macro_f1"])
        lines += ["", f"本次实测中 Macro-F1 最高的是 **{winner['name']}（{winner['report']['macro_f1']:.2%}）**。"
                  "冻结特征法只拟合线性分类器；全量微调会更新编码器以适应新闻标签。两者差异同时受池化方式、分类器、损失与参数更新范围影响，属于方法比较而非单因素消融。"]
        worst = sorted(r["per_class"], key=lambda p: p["f1"])[:3]
        lines += ["", "全量微调 F1 最低的三类为：" + "、".join(f"{p['label']} {p['f1']:.1%}（n={p['support']}）" for p in worst) + "。请结合逐类别图和混淆矩阵判断，少数类别的评测样本很少。"]
        if paired:
            lo, hi = paired["paired_bootstrap_95_ci"]
            lines += ["", f"相同 500 条中，RoBERTa 纠正了 BERT 的 {paired['only_roberta_correct']} 条错误，同时将 BERT 原本答对的 {paired['only_bert_correct']} 条答错。"
                      f"准确率差值的配对 Bootstrap 95% 区间为 [{lo*100:+.2f}, {hi*100:+.2f}] 个百分点（10,000 次重采样）。"
                      "这里只衡量评测样本波动，不含重训随机性；本实验仅跑 seed=42，没有做超参数搜索或多种子显著性结论。"]
    lines += ["", "## 训练与环境", "",
              "- 全量训练数据：53,360 条；3 epochs；batch=64；max_length=64；CLS 池化；dropout=0.1。",
              "- 编码器学习率 2e-5，分类头 1e-4；AdamW，weight_decay=0.01；10% warmup 后线性衰减；balanced 类别加权交叉熵；CUDA FP16。",
              "- 冻结特征：同一原始 RoBERTa 的 masked mean pooling，L2 Normalizer + LinearSVC(C=1, class_weight=balanced, max_iter=5000)，不更新编码器、不搜索超参。",
              "- 冻结特征最初使用 StandardScaler，SVM 达到默认 1000 次迭代上限仍未收敛。因此改用逐行 L2 归一化后重新运行，以最终收敛结果入表；修改基于优化器收敛诊断，没有搜索 C 或按评测分数选择设置。初次运行过程保留在 experiment.log，重跑记录见 frozen_rerun.log。",
              "- 本地 config 的 model_type 是 bert：中文 RoBERTa 使用 BERT 结构和 WordPiece，按 AutoModel/AutoTokenizer 加载，不能因目录名字而强制使用英文 RoBERTa 分词器。",
              "- 加载检查：预训练主干无 missing / mismatched keys；额外的预训练 MLM 任务头不参与分类。详见 model_loading.json。",
              f"- GPU：{config['gpu']}；依赖：" + "；".join(f"{k}={v}" for k,v in config["versions"].items()) + "。", "",
              "| 本次实测方法 | 拟合耗时（秒） | 批量推理（毫秒/条） |", "|---|---:|---:|"]
    for d in rows:
        if d["source"] == "本次实测":
            lines.append(f"| {d['name']} | {d['fit_seconds']:.2f} | {d['inference_seconds']*1000/d['report']['n_eval']:.3f} |")
    lines += ["", "耗时来自本机实测；神经方法含特征提取或 dev 验证，不含模型加载。神经推理使用预先编码的输入和 batch=64，不能解读为端到端单条请求延迟。历史方法没有可复核的同机耗时，因此不参与效率图。", "",
              "## 图表与文件", "",
              "1. `01_各方法指标对比.png`：所有方法 Accuracy / Macro-F1，历史结果带斜线。",
              "2. `02_逐类别F1对比.png`：TF-IDF、BERT 与两种 RoBERTa 方法的逐类 F1。",
              "3. `03_RoBERTa混淆矩阵.png`：数字为样本数，颜色按真实类别归一化。",
              "4. `04_RoBERTa训练曲线.png`：训练损失及独立 dev 指标。",
              "5. `05_本次实测效率对比.png`：同机拟合成本和批量推理耗时。",
              "6. `06_与原BERT预测变化.png`：相同样本的预测正确 / 错误变化。",
              "", "所有图同时提供可编辑 SVG。`metrics_summary.csv`、`per_class_metrics.csv` 用 UTF-8 BOM 编码，方便 Excel 打开；数值为 0~1 比例。"
              "`predictions/` 保存逐条预测及原结果来源哈希；`checkpoints/` 保存最佳神经分类器与冻结特征 SVM；其余 JSON 记录数据、配置、训练过程与配对统计。", "",
              "## 复现命令", "", "在 `D:/million/HW/WEEK06/code` 下执行：", "", "```powershell",
              "& 'D:/million/envs/py312/python.exe' -X utf8 comparison/run_experiments.py",
              "# 只重画图表与报告，不重训", "& 'D:/million/envs/py312/python.exe' -X utf8 comparison/plot_results.py",
              "# 用训练好的最佳模型对新标题分类", "& 'D:/million/envs/py312/python.exe' -X utf8 comparison/predict.py --text '中国队夺得比赛冠军'", "```", ""]
    (out / "实验报告.md").write_text("\n".join(lines), encoding="utf-8")


def build_report(out):
    out = Path(out)
    setup()
    rows, by_key = load_results(out)
    export_tables(rows, out)
    overview(rows, out)
    per_class(by_key, out)
    confusion(by_key, out)
    learning_curve(by_key, out)
    efficiency(rows, out)
    paired = paired_analysis(by_key, out)
    write_report(rows, by_key, paired, out)
    print(f"[图表] 已生成 CSV / JSON / 中文报告及 PNG + SVG：{out}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[2] / "result")
    build_report(parser.parse_args().out)
