"""加载本次 RoBERTa 分类 checkpoint，对新标题预测；不联网、不重新训练。"""

import argparse
import json
from pathlib import Path

from run_experiments import BertClassifier, amp, torch
from transformers import AutoTokenizer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--text", required=True, help="待分类的中文新闻标题")
    parser.add_argument("--checkpoint", type=Path,
                        default=Path(__file__).resolve().parents[2] / "result/checkpoints/roberta_best.pt")
    args = parser.parse_args()
    torch.set_num_threads(6)
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = AutoTokenizer.from_pretrained(saved["model_dir"], local_files_only=True)
    model = BertClassifier(saved["model_dir"], num_labels=len(saved["labels"]), pool=saved["pool"])
    model.load_state_dict(saved["state_dict"])
    model.to(device).eval()
    inputs = tokenizer(args.text, truncation=True, max_length=saved["max_length"], return_tensors="pt")
    with torch.inference_mode(), amp(device):
        probabilities = model(inputs["input_ids"].to(device), inputs["attention_mask"].to(device)).float().softmax(-1)[0]
    top = probabilities.topk(3)
    print(json.dumps({"text": args.text, "label": saved["labels"][top.indices[0].item()],
                      "top3": [{"label": saved["labels"][i], "probability": p}
                               for i, p in zip(top.indices.tolist(), top.values.tolist())]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
