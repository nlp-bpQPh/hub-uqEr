"""第六周：沿用课程数据与分类结构，对比本地 RoBERTa 和原有方法。

完整运行：python comparison/run_experiments.py
重新制图：python comparison/plot_results.py
所有新文件默认写入 WEEK06/result，课程 outputs 保留作历史证据。
"""

import argparse
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import sys
import time

# 强制离线：本作业不需要下载模型，也不调用付费 API。
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

CODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE))

from bert.train_bert import BertClassifier
from common.data import clean_val, load_splits, sample_subset
from common.labels import LABELS
from common.metrics import expected_calibration_error
from rule.classify_rule import classify


def write_json(path, value):
    """边实验边保存，训练中断时已经完成的结果仍可检查。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def digest(samples):
    body = json.dumps([(d["sentence"], d["label"]) for d in samples], ensure_ascii=False)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def metrics(y, pred):
    """固定 15 类；解析失败 -1 计为答错且保留在真实类别召回率分母中。

    课程旧指标先剔除了解析失败样本，会使生成模型 F1 略虚高。
    本次所有方法都从逐条预测重算，确保同一口径。
    """
    from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support
    y, pred = np.asarray(y), np.asarray(pred)
    p, r, f, support = precision_recall_fscore_support(
        y, pred, labels=list(range(len(LABELS))), zero_division=0
    )
    return {
        "accuracy": float(accuracy_score(y, pred)),
        "macro_f1": float(f.mean()),
        "weighted_f1": float(np.average(f, weights=support)),
        "used_classes": len(set(pred[pred >= 0].tolist())),
        "unparsed": int((pred < 0).sum()),
        "n_eval": len(y),
        "per_class": [{"label": name, "precision": float(p[i]), "recall": float(r[i]),
                       "f1": float(f[i]), "support": int(support[i])}
                      for i, name in enumerate(LABELS)],
        # 混淆矩阵增加最后一列，用来显示解析失败，行仍为真实的 15 类。
        "confusion_matrix": confusion_matrix(y, pred, labels=list(range(15)) + [-1])[:15].tolist(),
    }


def save_prediction(out, key, name, samples, pred, **extra):
    payload = {
        "key": key, "name": name, "source": "本次实测", "sample_sha256": digest(samples),
        "report": metrics([d["label"] for d in samples], pred),
        "preds": [{"idx": d["idx"], "text": d["sentence"], "true": d["label"], "pred": int(p)}
                  for d, p in zip(samples, pred)], **extra,
    }
    write_json(out / "predictions" / f"{key}.json", payload)
    print(f"[结果] {name}: Accuracy={payload['report']['accuracy']:.4f}, "
          f"Macro-F1={payload['report']['macro_f1']:.4f}", flush=True)
    return payload


def prepare_data(out, n_eval, seed):
    train, val = load_splits()
    clean, n_dup = clean_val(train, val)
    # 与课堂 seed=42 的 500 条样本顺序完全一致，才能复核历史结果。
    evaluation = sample_subset(clean, n_eval, seed)
    held_text = {d["sentence"] for d in evaluation}
    # 把评测标题整体排除，防止同一标题的另一个 idx 出现在选模集。
    dev_pool = [d for d in clean if d["sentence"] not in held_text]
    dev = sample_subset(dev_pool, min(1000, len(dev_pool)), seed + 1)
    train_text = {d["sentence"] for d in train}
    assert not train_text & held_text
    assert not train_text & {d["sentence"] for d in dev}
    assert not held_text & {d["sentence"] for d in dev}
    protocol = {
        "n_train": len(train), "n_val_original": len(val), "n_removed_overlap": n_dup,
        "n_clean": len(clean), "n_eval": len(evaluation), "n_dev": len(dev), "seed": seed,
        "evaluation_sha256": digest(evaluation), "development_sha256": digest(dev),
        "selection": "只按独立 dev Macro-F1 选择 checkpoint；最终 500 条只评测一次",
        "training_data": "全部课程训练集；不抽样训练；未去除训练集内部重复，沿用原实验",
    }
    write_json(out / "data_protocol.json", protocol)
    write_json(out / "eval_samples.json", evaluation)
    write_json(out / "dev_samples.json", dev)
    return train, dev, evaluation, protocol


def run_light(train, samples, out):
    from collections import Counter
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.svm import LinearSVC
    start = time.perf_counter()
    fallback = Counter(d["label"] for d in train).most_common(1)[0][0]
    pred = [classify(d["sentence"], fallback) for d in samples]
    save_prediction(out, "rule", "规则 / 关键词", samples, pred,
                    fit_seconds=0.0, inference_seconds=time.perf_counter() - start)
    start = time.perf_counter()
    vec = TfidfVectorizer(analyzer="char", ngram_range=(1, 2), max_features=300000)
    x = vec.fit_transform([d["sentence"] for d in train])
    clf = LinearSVC(C=1.0, random_state=42).fit(x, [d["label"] for d in train])
    fit = time.perf_counter() - start
    start = time.perf_counter()
    pred = clf.predict(vec.transform([d["sentence"] for d in samples]))
    save_prediction(out, "tfidf", "TF-IDF + SVM", samples, pred,
                    fit_seconds=fit, inference_seconds=time.perf_counter() - start,
                    settings={"analyzer": "char", "ngram_range": [1, 2], "max_features": 300000, "C": 1.0})


def import_history(samples, out):
    sources = [
        ("bert_history", "BERT 微调", "bert_pred.json"),
        ("qwen_zero_history", "Qwen3 零样本", "zero_shot_pred.json"),
        ("qwen_lora_history", "Qwen3 LoRA", "lora_pred.json"),
        ("qwen_full_history", "Qwen3 全量微调", "full_ft_pred.json"),
        ("api_history", "API 零样本", "api_zero_shot_pred.json"),
    ]
    for key, name, filename in sources:
        path = CODE / "outputs" / filename
        raw = json.loads(path.read_text(encoding="utf-8"))
        rows = raw.get("preds", [])
        # 不凭 n_eval/seed 就认为可比，逐个核对文本、标签和顺序。
        if len(rows) != len(samples) or any(
            p["text"] != d["sentence"] or p["true"] != d["label"]
            for p, d in zip(rows, samples)
        ):
            print(f"[跳过历史] {filename}: 与本次样本不一致", flush=True)
            continue
        save_prediction(out, key, name, samples, [p["pred"] for p in rows],
                        source="课程历史预测（逐条核对并重算指标）",
                        source_file=str(path), source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                        original_report=raw["report"], fit_seconds=None, inference_seconds=None)


def tokenize_data(samples, tok, max_length):
    """一次性编码，避免每个 epoch 在 __getitem__ 里重复做中文分词。"""
    enc = tok([d["sentence"] for d in samples], truncation=True, max_length=max_length,
              padding="max_length", return_tensors="pt")
    return TensorDataset(enc["input_ids"], enc["attention_mask"],
                         torch.tensor([d["label"] for d in samples], dtype=torch.long))


def sync(device):
    if device == "cuda":
        torch.cuda.synchronize()


def amp(device):
    return torch.autocast(device_type=device, dtype=torch.float16, enabled=(device == "cuda"))


@torch.inference_mode()
def infer(model, data, device, batch_size):
    model.eval()
    probs = []
    loader = DataLoader(data, batch_size=batch_size, pin_memory=(device == "cuda"))
    sync(device)
    start = time.perf_counter()
    for ids, mask, _ in loader:
        with amp(device):
            logits = model(ids.to(device), mask.to(device))
        probs.append(logits.float().softmax(-1).cpu())
    sync(device)
    return torch.cat(probs).numpy(), time.perf_counter() - start


@torch.inference_mode()
def features(model, data, device, batch_size):
    """冻结编码器取 mask 后的均值特征，线性 SVM 只学习分类边界。"""
    model.eval()
    result = []
    loader = DataLoader(data, batch_size=batch_size, pin_memory=(device == "cuda"))
    for step, (ids, mask, _) in enumerate(loader):
        mask = mask.to(device)
        with amp(device):
            hs = model.bert(input_ids=ids.to(device), attention_mask=mask,
                            return_dict=True).last_hidden_state
            m = mask.unsqueeze(-1).float()
            x = (hs.float() * m).sum(1) / m.sum(1).clamp(min=1)
        result.append(x.cpu().numpy())
        if step % 100 == 0:
            print(f"[冻结特征] {step}/{len(loader)} batch", flush=True)
    return np.concatenate(result)


def make_model(model_dir, device, out):
    from transformers import AutoModel
    # 保留课程分类结构；额外严格核查 encoder 是否完整加载。
    model = BertClassifier.__new__(BertClassifier)
    torch.nn.Module.__init__(model)
    model.bert, info = AutoModel.from_pretrained(str(model_dir), local_files_only=True,
                                                output_loading_info=True)
    if info["missing_keys"] or info["mismatched_keys"] or info["error_msgs"]:
        raise RuntimeError(f"预训练主干加载不完整，禁止用随机主干冒充预训练模型：{info}")
    model.pool = "cls"
    model.dropout = torch.nn.Dropout(0.1)
    model.classifier = torch.nn.Linear(model.bert.config.hidden_size, len(LABELS))
    write_json(out / "model_loading.json", {k: sorted(v) if isinstance(v, set) else v for k, v in info.items()})
    return model.to(device)


def run_frozen(model, train_data, eval_data, samples, args, device):
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import Normalizer
    from sklearn.svm import LinearSVC
    start = time.perf_counter()
    x = features(model, train_data, device, args.batch_size)
    # 逐行 L2 归一化限制向量尺度，避免稠密高维特征导致 SVM 优化病态。
    # 不用评测集搜索 C，固定 C=1；提高迭代上限并记录是否真正收敛。
    clf = make_pipeline(Normalizer(), LinearSVC(C=1.0, class_weight="balanced",
                                               max_iter=5000, random_state=args.seed))
    clf.fit(x, train_data.tensors[-1].numpy())
    if clf[-1].n_iter_ >= 5000:
        raise RuntimeError("冻结特征 SVM 尚未收敛，停止发布该结果，请检查优化器诊断")
    sync(device)
    fit = time.perf_counter() - start
    start = time.perf_counter()
    pred = clf.predict(features(model, eval_data, device, args.batch_size))
    sync(device)
    inference = time.perf_counter() - start
    import joblib
    joblib.dump(clf, args.out / "checkpoints" / "frozen_svm.joblib")
    save_prediction(args.out, "roberta_frozen", "RoBERTa 冻结特征 + SVM", samples, pred,
                    fit_seconds=fit, inference_seconds=inference,
                    settings={"pool": "masked_mean", "classifier": "L2 Normalizer + LinearSVC", "C": 1.0,
                              "class_weight": "balanced", "encoder_trainable": False,
                              "max_iter": 5000, "n_iter": int(clf[-1].n_iter_),
                              "converged": bool(clf[-1].n_iter_ < 5000)})


def train_full(model, train_data, dev_data, eval_data, samples, args, device):
    from sklearn.utils.class_weight import compute_class_weight
    seed_everything(args.seed)
    loader = DataLoader(train_data, batch_size=args.batch_size, shuffle=True,
                        generator=torch.Generator().manual_seed(args.seed), pin_memory=(device == "cuda"))
    weights = compute_class_weight("balanced", classes=np.arange(len(LABELS)), y=train_data.tensors[-1].numpy())
    criterion = torch.nn.CrossEntropyLoss(weight=torch.tensor(weights, dtype=torch.float32, device=device))
    optimizer = torch.optim.AdamW([
        {"params": model.bert.parameters(), "lr": args.lr},
        {"params": model.classifier.parameters(), "lr": args.lr * 5},
    ], weight_decay=0.01)
    n_steps = len(loader) * args.epochs
    warmup = int(n_steps * 0.1)
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda s:
        s / max(1, warmup) if s < warmup else max(0.0, (n_steps - s) / max(1, n_steps - warmup)))
    scaler = torch.amp.GradScaler("cuda", enabled=(device == "cuda"))
    best, best_epoch, history = -1.0, 0, []
    checkpoint = args.out / "checkpoints" / "roberta_best.pt"
    start = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train()
        epoch_start, losses, epoch_skipped = time.perf_counter(), [], 0
        for step, (ids, mask, y) in enumerate(loader, 1):
            optimizer.zero_grad(set_to_none=True)
            with amp(device):
                loss = criterion(model(ids.to(device), mask.to(device)), y.to(device))
            if not torch.isfinite(loss):
                raise RuntimeError(f"训练出现非有限损失：epoch={epoch}, step={step}")
            scaler.scale(loss).backward()
            # 与 demo 一样保持加权 CE、分层学习率和 10% warmup，不叠加其它训练技巧。
            previous_scale = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            # AMP 溢出会跳过 optimizer.step，此时学习率也不提前走一步。
            if scaler.get_scale() >= previous_scale:
                scheduler.step()
            else:
                epoch_skipped += 1
            losses.append(loss.item())
            if step == 1 or step % 100 == 0 or step == len(loader):
                print(f"[训练] epoch={epoch}/{args.epochs}, step={step}/{len(loader)}, "
                      f"loss={loss.item():.4f}, elapsed={time.perf_counter()-epoch_start:.1f}s", flush=True)
        probabilities, _ = infer(model, dev_data, device, args.batch_size)
        report = metrics(dev_data.tensors[-1].numpy(), probabilities.argmax(-1))
        row = {"epoch": epoch, "train_loss": float(np.mean(losses)),
               "dev_accuracy": report["accuracy"], "dev_macro_f1": report["macro_f1"],
               "elapsed_seconds": time.perf_counter() - epoch_start, "amp_skipped_updates": epoch_skipped}
        history.append(row)
        write_json(args.out / "training_history.json", history)
        print(f"[验证] {row}", flush=True)
        if report["macro_f1"] > best:
            best, best_epoch = report["macro_f1"], epoch
            torch.save({"state_dict": model.state_dict(), "model_dir": str(args.model), "pool": "cls",
                        "max_length": args.max_length, "labels": LABELS, "seed": args.seed,
                        "best_epoch": best_epoch, "dev_macro_f1": best}, checkpoint)
    sync(device)
    fit = time.perf_counter() - start
    saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
    model.load_state_dict(saved["state_dict"])
    # GPU 预热后再计时，不把模型加载时间混入批量推理延迟。
    infer(model, TensorDataset(*(t[:args.batch_size] for t in eval_data.tensors)), device, args.batch_size)
    probabilities, inference = infer(model, eval_data, device, args.batch_size)
    save_prediction(args.out, "roberta_full", "RoBERTa 全量微调", samples, probabilities.argmax(-1),
                    fit_seconds=fit, inference_seconds=inference,
                    ece=expected_calibration_error([d["label"] for d in samples], probabilities),
                    best_epoch=best_epoch, dev_macro_f1=best, history=history,
                    settings={"pool": "cls", "epochs": args.epochs, "batch_size": args.batch_size,
                              "backbone_lr": args.lr, "head_lr": args.lr * 5, "warmup_ratio": 0.1,
                              "weight_decay": 0.01, "loss": "balanced weighted cross entropy",
                              "max_length": args.max_length, "seed": args.seed, "amp": device == "cuda"})
    np.savez_compressed(args.out / "roberta_probabilities.npz", probabilities=probabilities,
                        labels=np.array([d["label"] for d in samples]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=Path("D:/model/RoBERTa-Chinese-base"))
    parser.add_argument("--out", type=Path, default=CODE.parent / "result")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--max-length", type=int, default=64)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-eval", type=int, default=500)
    parser.add_argument("--skip-frozen", action="store_true")
    parser.add_argument("--frozen-only", action="store_true", help="只复现冻结特征实验；保留全量微调结果与配置")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1 or args.n_eval < 1:
        parser.error("epochs、batch-size、n-eval 必须为正整数")
    if args.skip_frozen and args.frozen_only:
        parser.error("--skip-frozen 和 --frozen-only 不能同时使用")
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "checkpoints").mkdir(exist_ok=True)
    torch.set_num_threads(6)
    seed_everything(args.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    train, dev, samples, protocol = prepare_data(args.out, args.n_eval, args.seed)
    if args.frozen_only:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(args.model), local_files_only=True)
        train_data = tokenize_data(train, tokenizer, args.max_length)
        eval_data = tokenize_data(samples, tokenizer, args.max_length)
        model = make_model(args.model, device, args.out)
        run_frozen(model, train_data, eval_data, samples, args, device)
        from plot_results import build_report
        build_report(args.out)
        return
    versions = {m: importlib.metadata.version(m) for m in ["torch", "transformers", "scikit-learn", "numpy", "matplotlib"]}
    write_json(args.out / "experiment_config.json", {
        **{k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        "versions": versions, "device": device,
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else None,
        "model_config": json.loads((args.model / "config.json").read_text(encoding="utf-8")),
        "data": protocol,
    })
    print(f"[配置] device={device}, train={len(train)}, dev={len(dev)}, eval={len(samples)}", flush=True)
    import_history(samples, args.out)
    run_light(train, samples, args.out)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(args.model), local_files_only=True)
    train_data = tokenize_data(train, tokenizer, args.max_length)
    dev_data = tokenize_data(dev, tokenizer, args.max_length)
    eval_data = tokenize_data(samples, tokenizer, args.max_length)
    model = make_model(args.model, device, args.out)
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()
    if not args.skip_frozen:
        run_frozen(model, train_data, eval_data, samples, args, device)
    gc.collect()
    train_full(model, train_data, dev_data, eval_data, samples, args, device)
    write_json(args.out / "resource_usage.json", {
        "peak_gpu_allocated_mb": torch.cuda.max_memory_allocated() / 2**20 if device == "cuda" else None,
        "peak_gpu_reserved_mb": torch.cuda.max_memory_reserved() / 2**20 if device == "cuda" else None,
    })
    from plot_results import build_report
    build_report(args.out)
    print(f"[完成] {args.out}", flush=True)


if __name__ == "__main__":
    main()
